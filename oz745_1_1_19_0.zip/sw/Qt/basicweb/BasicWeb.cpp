#include <QtGui>
#include <QtNetwork>
#include <QtWebKit>
#include "BasicWeb.h"
#include <iostream>
BasicWeb::BasicWeb(const QUrl& url, bool hotkeys) : QMainWindow(), 
  m_fullScreen( false ), m_transparent( false )
{
    progress = 0;

    QNetworkProxyFactory::setUseSystemConfiguration(true);

    view = new QWebView(this);
    view->load(url);
    connect(view, SIGNAL(loadFinished(bool)), SLOT(adjustLocation()));
    connect(view, SIGNAL(titleChanged(QString)), SLOT(adjustTitle()));
    connect(view, SIGNAL(loadProgress(int)), SLOT(setProgress(int)));
    connect(view, SIGNAL(loadFinished(bool)), SLOT(finishLoading(bool)));

    locationEdit = new QLineEdit(this);
    locationEdit->setSizePolicy(QSizePolicy::Expanding, locationEdit->sizePolicy().verticalPolicy());
    connect(locationEdit, SIGNAL(returnPressed()), SLOT(changeLocation()));

    QToolBar *toolBar = addToolBar(tr("Navigation"));
    toolBar->addAction(view->pageAction(QWebPage::Back));
    toolBar->addAction(view->pageAction(QWebPage::Forward));
    toolBar->addAction(view->pageAction(QWebPage::Reload));
    toolBar->addAction(view->pageAction(QWebPage::Stop));
    toolBar->addWidget(locationEdit);

    setCentralWidget(view);

    if ( hotkeys )
    {
        new QShortcut( QKeySequence(Qt::Key_F11), this, SLOT(toggleFullScreen()));
        new QShortcut( QKeySequence(Qt::CTRL + Qt::Key_T), this, SLOT(toggleTransparent()));
    }
}

void BasicWeb::SetTransparent( bool transparent )
{
    if ( m_transparent != transparent )
        m_transparent = transparent;
    else
        return;
    if ( m_transparent )
    {
        setStyleSheet("background:transparent;");
    }
    else
    {
        setStyleSheet("");
    }
}

void BasicWeb::SetFullScreen( bool full )
{
    if ( m_fullScreen != full )
      m_fullScreen = full;
    else
      return;

    Qt::WindowFlags flags = windowFlags();
    flags &= ~Qt::FramelessWindowHint;
    if ( m_fullScreen )
        flags |= Qt::FramelessWindowHint;
    setWindowFlags(flags);

    QList<QToolBar *> toolbars = findChildren<QToolBar *>();
    for ( int i = 0; i < toolbars.size(); ++i )
    {
        if ( m_fullScreen )
            (toolbars.at(i))->hide();
        else
            (toolbars.at(i))->show();
    }

    setWindowState( Qt::WindowNoState );
    setWindowState( Qt::WindowMaximized );

    showMaximized();    
}

void BasicWeb::toggleFullScreen()
{
    SetFullScreen( !m_fullScreen );
}

void BasicWeb::toggleTransparent()
{
    SetTransparent( !m_transparent );
}

void BasicWeb::adjustLocation()
{
    locationEdit->setText(view->url().toString());
}

void BasicWeb::changeLocation()
{
    view->stop();
    QUrl url = QUrl(locationEdit->text());
    view->load(url);
    view->setFocus();
}

void BasicWeb::adjustTitle()
{
    if (progress <= 0 || progress >= 100)
        setWindowTitle(view->title());
    else
        setWindowTitle(QString("%1 (%2%)").arg(view->title()).arg(progress));
}

void BasicWeb::setProgress(int p)
{
    progress = p;
    adjustTitle();
}

void BasicWeb::finishLoading(bool)
{
    progress = 100;
    adjustTitle();
}


