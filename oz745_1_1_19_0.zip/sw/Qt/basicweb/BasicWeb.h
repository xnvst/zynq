#include <QtGui>

class QWebView;
QT_BEGIN_NAMESPACE
class QLineEdit;
QT_END_NAMESPACE

class BasicWeb : public QMainWindow
{
    Q_OBJECT

public:
    BasicWeb(const QUrl& url, bool hotkeys = true );

    void SetFullScreen( bool full );
    void SetTransparent( bool transparent );
protected slots:
    void adjustLocation();
    void changeLocation();
    void adjustTitle();
    void setProgress(int p);
    void finishLoading(bool);

    void toggleFullScreen();
    void toggleTransparent();
private:
    QWebView *view;
    QLineEdit *locationEdit;
    int progress;
    bool m_fullScreen;
    bool m_transparent;
};

