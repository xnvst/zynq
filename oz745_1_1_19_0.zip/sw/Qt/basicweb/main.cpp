#include <QtGui>
#include "BasicWeb.h"
#include <QWSServer>
#include <QColor>

int main(int argc, char * argv[])
{
    bool kioskMode = false;
    bool transparentMode = false;
    //QWSServer::setBackground( Qt::transparent );
    QWSServer::setBackground( QColor( 0x00,0x00,0x00,0x00) );

    QApplication app(argc, argv);
    QUrl url("http://localhost");

    QStringList argList = QCoreApplication::arguments();
    kioskMode = argList.contains( "--kiosk", Qt::CaseInsensitive );
    transparentMode = argList.contains( "--transparent", Qt::CaseInsensitive );

    BasicWeb *browser = new BasicWeb(url, !kioskMode);
    browser->showMaximized();
    browser->setWindowIcon( QIcon( "favicon.ico" ) );

    if ( kioskMode )
      browser->SetFullScreen( true );
    if ( transparentMode )
      browser->SetTransparent( true );


    return app.exec();
}

