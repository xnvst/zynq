#include <QtGui>
class  myMainWindow:public QMainWindow
{
public:
	myMainWindow(): QMainWindow() {};
	~myMainWindow(){};

	void paintEvent(QPaintEvent*)
	{
		QPainter painter(this);

		// setup and draw some text
		painter.setPen( Qt::black);
		QFont font;
		font.setPointSize( 18 );
		painter.setFont( font );
		painter.drawText( 180, 50, "Hello World. This is a Qt Demo" );

		// Draw the OmniTek Logo
		painter.fillRect(  50, 125, 50, 50, Qt::red );
		painter.fillRect( 100, 175, 50, 50, Qt::yellow );
		painter.fillRect(  50, 225, 50, 50, Qt::blue );

		QPen pen;
		pen.setWidth(7);
		painter.setPen(pen);

		painter.drawLine(  25, 125, 175, 125 );
		painter.drawLine(  25, 175, 175, 175 );
		painter.drawLine(  25, 225, 175, 225 );
		painter.drawLine(  25, 275, 175, 275 );
	
		painter.drawLine(  50, 100,  50, 300 );
		painter.drawLine( 100, 100, 100, 300 );
		painter.drawLine( 150, 100, 150, 300 );


		// draw the ellipse
		painter.setBrush(Qt::cyan);
		painter.setPen( Qt::red);
		painter.drawEllipse( 225, 100, 200, 200 );

		// draw the star
		painter.setPen( Qt::black);
		painter.setBrush(Qt::green);
		float sscale = 1.85;
		float sxoff = 450;
		float syoff = 110;
		QPolygon star;
		star 	<< QPoint( ( 50*sscale )+ sxoff, (   0*sscale )+ syoff )
			<< QPoint( ( 65*sscale )+ sxoff, (  40*sscale )+ syoff )
			<< QPoint( (100*sscale )+ sxoff, (  40*sscale )+ syoff )
			<< QPoint( ( 70*sscale )+ sxoff, (  60*sscale )+ syoff )
			<< QPoint( ( 80*sscale )+ sxoff, ( 100*sscale )+ syoff )
			<< QPoint( ( 50*sscale )+ sxoff, (  75*sscale )+ syoff )
			<< QPoint( ( 20*sscale )+ sxoff, ( 100*sscale )+ syoff )
			<< QPoint( ( 30*sscale )+ sxoff, (  60*sscale )+ syoff )
			<< QPoint( (  0*sscale )+ sxoff, (  40*sscale )+ syoff )
			<< QPoint( ( 35*sscale )+ sxoff, (  40*sscale )+ syoff );

		painter.drawPolygon( star );
	};    
};

int main(int argc, char **argv)
{
	QApplication app(argc, argv);
	myMainWindow *window = new myMainWindow();    

	window->setWindowTitle(QString::fromUtf8("Qt Example App"));
	window->resize(650, 350);	       
	window->show();
	return app.exec();
}
