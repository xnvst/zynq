/*
 * oz745_sys_config.h
 *
 *  Created on: Jul 25, 2014
 *      Author: richard
 */

#ifndef OZ745_SYS_CONFIG_H_
#define OZ745_SYS_CONFIG_H_

#include "oz745_i2c_utils.h"

#ifdef XPAR_PS7_I2C_0_DEVICE_ID

int oz745_zynq_speed_grade(XIicPs *iicInstance);

#endif // XPAR_PS7_I2C_0_DEVICE_ID

#endif /* OZ745_SYS_CONFIG_H_ */
