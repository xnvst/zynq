#include "xparameters.h"
#ifdef XPAR_PS7_CORTEXA9_0_CPU_CLK_FREQ_HZ
#ifdef XPAR_PS7_I2C_0_DEVICE_ID

//----------------------------------------------------------------
//
// Design Name:         OZ745 I2C Utilities
// Target Devices:      Zynq-7
//
// Tool versions:       ISE 14.1
//
// Description:         OZ745 I2C Utilities.
//                      - I2C Multiplexer
//
//----------------------------------------------------------------

#include "sleep.h"
#include "oz745_i2c_utils.h"

// I2C Init Parameters
#define IIC_DEVICE_ID  XPAR_XIICPS_0_DEVICE_ID
#define IIC_SCLK_RATE  100000
#define IIC_TIME_OUT   0x7f
#define SLEEP_TIME     10000

/*
 * hack to work around wrong CPU clock frequency value in xparameters_ps.h;
 * The CPU clock frequency is used in the usleep function (COUNTS_PER_SECOND)
 * and for the IIC base frequency (IICPS_0_CLOCK_HZ)
 */
#define CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ  800000000
#define COUNTS_PER_SECOND  (CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ / 64)
#define IICPS_0_CLOCK_HZ  (CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ / 6)

// I2C Addresses
#define OZ745_I2C_MUX_ADDR  0x77 // (PCA9458)
// I2C Config Struct
typedef struct {
	u8 Reg;
	u8 Data;
	u8 Init;
} OZ745_I2C_CONFIG;

XIicPs _gIicInstance;

static int oz745_wait_usec(unsigned int useconds) {
#if SIM
	// no delay for simulation
	return;
#endif

	//usleep(delay);

	unsigned long tEnd, tCur;
	unsigned int reg;

	/* check requested delay for out of range */

	if (useconds == 0) {
		return 0;
	}

	if (((COUNTS_PER_SECOND / 1000000) > 0)
			&& (useconds > (0xFFFFFFFF / (COUNTS_PER_SECOND / 1000000)))) {
		return -1;
	}

	/* enable the counter */
	mtcp(XREG_CP15_PERF_MONITOR_CTRL, 1);
#ifdef __GNUC__
	reg = mfcp(XREG_CP15_COUNT_ENABLE_SET);
#else
	{	register unsigned int Reg __asm(XREG_CP15_COUNT_ENABLE_SET);
		reg = Reg;}
#endif
	mtcp(XREG_CP15_COUNT_ENABLE_SET, reg | 0x80000000);

#ifdef __GNUC__
	tCur = mfcp(XREG_CP15_PERF_CYCLE_COUNTER);
#else
	{	register unsigned int Reg __asm(XREG_CP15_PERF_CYCLE_COUNTER);
		tCur = Reg;}
#endif
	tEnd = tCur + (useconds * (COUNTS_PER_SECOND / 1000000));

	do {
#ifdef __GNUC__
		tCur = mfcp(XREG_CP15_PERF_CYCLE_COUNTER);
#else
		{	register unsigned int Reg __asm(XREG_CP15_PERF_CYCLE_COUNTER);
			tCur = Reg;}
#endif
	} while (tCur < tEnd);

	return 0;
}

int oz745_iic_init(XIicPs *IicPs) {
	int Status;
	XIicPs_Config *IicPs_Config;

	/*
	 * Initialize the IIC driver.
	 */
	IicPs_Config = XIicPs_LookupConfig(IIC_DEVICE_ID);
	if (IicPs_Config == NULL ) {
		printf("No XIicPs instance found for ID %d\n\r", IIC_DEVICE_ID);
		return XST_FAILURE;
	}

	Status = XIicPs_CfgInitialize(IicPs, IicPs_Config,
			IicPs_Config->BaseAddress);
	if (Status != XST_SUCCESS) {
		printf("XIicPs Initialization failed for ID %d\n\r", IIC_DEVICE_ID);
		return XST_FAILURE;
	}

	/*
	 * Set the IIC serial clock rate.
	 */
	Status = XIicPs_SetSClk(IicPs, IIC_SCLK_RATE);
	if (Status != XST_SUCCESS) {
		printf("Setting XIicPs clock rate failed for ID %d\n\r", IIC_DEVICE_ID);
		return XST_FAILURE;
	}

	/*
	 * Increase the default timeout value.
	 */
	XIicPs_WriteReg(IicPs_Config->BaseAddress, XIICPS_TIME_OUT_OFFSET,
			IIC_TIME_OUT);

	return XST_SUCCESS;
}

int oz745_iic_write1(XIicPs *IicPs, u8 Address, u8 Data) {
	int Status;

	/*
	 * Wait until bus is idle to start another transfer.
	 */
	while (XIicPs_BusIsBusy(IicPs)) {
		/* NOP */
	}

	/*
	 * Send the buffer using the IIC and check for errors.
	 */
	Status = XIicPs_MasterSendPolled(IicPs, &Data, 1, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterSendPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	return XST_SUCCESS;
}

int oz745_iic_writeb(XIicPs *IicPs, u8 Address, u8 *WriteBuffer, u32 len) {
	int Status;

	/*
	 * Wait until bus is idle to start another transfer.
	 */
	while (XIicPs_BusIsBusy(IicPs)) {
		/* NOP */
	}

	/*
	 * Send the buffer using the IIC and check for errors.
	 */
	Status = XIicPs_MasterSendPolled(IicPs, WriteBuffer, len, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterSendPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	return XST_SUCCESS;
}

int oz745_iic_write_ex(XIicPs *IicPs, u8 Address, u8 *regs, u8 *data, int len) {
	int i;
	u8 WriteBuffer[2];
	int Status;

	for (i = 0; i < len; i++) {
		WriteBuffer[0] = regs[i];
		WriteBuffer[1] = data[i];

		/*
		 * Wait until bus is idle to start another transfer.
		 */
		while (XIicPs_BusIsBusy(IicPs)) {
			/* NOP */
		}

		/*
		 * Send the buffer using the IIC and check for errors.
		 */
		Status = XIicPs_MasterSendPolled(IicPs, WriteBuffer, 2, Address);
		if (Status != XST_SUCCESS) {
			printf("XIicPs_MasterSendPolled error!\n\r");
			return XST_FAILURE;
		}
	}
	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	return XST_SUCCESS;
}

int oz745_iic_write2(XIicPs *IicPs, u8 Address, u8 Register, u8 Data) {
	u8 WriteBuffer[2];
	int Status;

	/*
	 * A temporary write buffer must be used which contains both the address
	 * and the data to be written, put the address in first
	 */
	WriteBuffer[0] = Register;
	WriteBuffer[1] = Data;

	/*
	 * Wait until bus is idle to start another transfer.
	 */
	while (XIicPs_BusIsBusy(IicPs)) {
		/* NOP */
	}

	/*
	 * Send the buffer using the IIC and check for errors.
	 */
	Status = XIicPs_MasterSendPolled(IicPs, WriteBuffer, 2, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterSendPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	return XST_SUCCESS;
}

int oz745_iic_read1(XIicPs *IicPs, u8 Address, u8 *Data) {
	int Status;

	/*
	 * Wait until bus is idle to start another transfer.
	 */
	while (XIicPs_BusIsBusy(IicPs)) {
		/* NOP */
	}

	/*
	 * Receive the data.
	 */
	Status = XIicPs_MasterRecvPolled(IicPs, Data, 1, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterRecvPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	return XST_SUCCESS;
}

int oz745_iic_read2(XIicPs *IicPs, u8 Address, u8 Register, u8 *Data,
		u8 ByteCount) {
	int Status;

	/*
	 * Wait until bus is idle to start another transfer.
	 */
	while (XIicPs_BusIsBusy(IicPs)) {
		/* NOP */
	}

	/*
	 * Set the IIC Repeated Start option.
	 */
	Status = XIicPs_SetOptions(IicPs, XIICPS_REP_START_OPTION);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Send the buffer using the IIC and check for errors.
	 */
	Status = XIicPs_MasterSendPolled(IicPs, &Register, 1, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterSendPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	/*
	 * Receive the data.
	 */
	Status = XIicPs_MasterRecvPolled(IicPs, Data, ByteCount, Address);
	if (Status != XST_SUCCESS) {
		printf("XIicPs_MasterRecvPolled error!\n\r");
		return XST_FAILURE;
	}

	// sleep 10ms
	oz745_wait_usec(SLEEP_TIME);

	/*
	 * Clear the IIC Repeated Start option.
	 */
	Status = XIicPs_ClearOptions(IicPs, XIICPS_REP_START_OPTION);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	//xil_printf("%02X ", *Data);
	return XST_SUCCESS;
}


void oz745_iic_mux(XIicPs *IicPs, u8 MuxSelect) {
	u8 read_data;

	// WARNING MUX is a bit field not a Number!!
	oz745_iic_write1(IicPs, OZ745_I2C_MUX_ADDR, MuxSelect);

	oz745_iic_read1(IicPs, OZ745_I2C_MUX_ADDR, &read_data);
}

//int i2c_start(void) {
//
//	if (oz745_iic_init(&_gIicInstance) != XST_SUCCESS) {
//		xil_printf("IIC Failed\n\r");
//		return XST_FAILURE;
//	}
//	xil_printf("IIC Started\r\n");
//	return XST_SUCCESS;
//}

#endif //XPAR_PS7_I2C_0_DEVICE_ID

#endif // XPAR_PS7_CORTEXA9_0_CPU_CLK_FREQ_HZ
