/*
 * oz745_sys_config.c
 *
 *  Created on: Jul 25, 2014
 *      Author: richard
 */
#include "oz745_sys_config.h"
#ifdef XPAR_PS7_I2C_0_DEVICE_ID

#pragma pack(push, 1)
typedef struct
{
	u8 type;
	u8 version;
	u8	manufacture_date[4];
	u8	num_keys;
	u8 checksum;
} HEADER;

typedef struct
{
	u8 key;
	u8 value;
}KEY_VALUE;

#pragma pack(pop)

typedef enum
{
	DATA_KEY_BOARD_REVISION = 0x00,
	DATA_KEY_MOD_LEVEL,
	DATA_KEY_ZYNQ_SPEED,
	DATA_KEY_EYE_EQUALIZER,
	DATA_KEY_BOM_LEVEL,
	DATA_KEY_MAX
}DATA_KEYS;

#define DATA_OFFSET (128)

u8 cal_chksum(char *pBuffer, int size)
{
	u8 chk = 0;
	int i;

	for( i=0; i<size; i++ )
		chk += pBuffer[i];

	chk = 255 - chk;
	return chk;
}

#define OZ745_I2C_MAC_EEPROM  (0xA8>>1)

int oz745_zynq_speed_grade(XIicPs *iicInstance)
{
	int speed_grade = 1;
	HEADER header;
	u8 *pPtr;
	int i;
	KEY_VALUE key_value;

	/* Write the Address to be read */
	if( oz745_iic_write1(iicInstance, OZ745_I2C_MAC_EEPROM, DATA_OFFSET) != XST_SUCCESS )
		return speed_grade;

	/* Read the header first */
	pPtr = (u8*)&header;
	for( i=0; i<sizeof(HEADER); i++ )
	{
		/* Read the data byte */
		if( oz745_iic_read1(iicInstance, OZ745_I2C_MAC_EEPROM, pPtr) != XST_SUCCESS )
			return speed_grade;
		pPtr++;
	}

	/* Check that the header is valid */
	if( header.checksum != cal_chksum((char*)&header, sizeof(HEADER)-1) )
		return speed_grade;

	/* Now read the keys, looking for the speed grade key */
	pPtr = (u8*)&key_value;
	for( i=0; i<header.num_keys; i++ )
	{
		if( oz745_iic_read1(iicInstance, OZ745_I2C_MAC_EEPROM, pPtr) != XST_SUCCESS )
			return speed_grade;
		if( oz745_iic_read1(iicInstance, OZ745_I2C_MAC_EEPROM, pPtr+1) != XST_SUCCESS )
			return speed_grade;

		if( key_value.key == DATA_KEY_ZYNQ_SPEED )
		{
			speed_grade = key_value.value;
			break;
		}
	}
	return speed_grade;
}

#endif


