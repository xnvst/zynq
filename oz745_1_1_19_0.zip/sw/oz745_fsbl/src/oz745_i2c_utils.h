//----------------------------------------------------------------
//
// Design Name:         OZ745 I2C Utilities
// Target Devices:      Zynq-7
//
// Tool versions:       ISE 14.1
//
// Description:         OZ745 I2C Utilities.
//                      - I2C Multiplexer
//                      - HDMI
//						- Clock Synthesizer
//                      - PMBus
//
//----------------------------------------------------------------

#ifndef __OZ745_I2C_UTILS_H__
#define __OZ745_I2C_UTILS_H__

#include <stdio.h>
#include "xparameters.h"
#include "xiicps.h"

#ifdef XPAR_PS7_I2C_0_DEVICE_ID

// I2C Init Function
extern int  oz745_iic_init( XIicPs *IicPs );

// I2C MUX Function
extern void oz745_iic_mux( XIicPs *IicPs, u8 MuxSelect );

extern int oz745_iic_write1(XIicPs *IicPs, u8 Address, u8 Data);

extern int oz745_iic_read1(XIicPs *IicPs, u8 Address, u8 *Data);
extern int oz745_iic_read2(XIicPs *IicPs, u8 Address, u8 Register, u8 *Data, u8 ByteCount);

//int i2c_start(void);

#endif // XPAR_PS7_I2C_0_DEVICE_ID

#endif // __OZ745_I2C_UTILS_H__
