
var host_override="";
var boxIn=[];
var boxOut=[];
var trackbar_osd_alpha=[];
var trackbar_scaler_alpha=[];
var inputs = [];

function toggle_body( id, cls, tab_cls )
{
	var elms = document.getElementsByClassName( cls );
	var m = '^.*' + id + '$'
	for ( var i =0; i < elms.length; i++ )
	{
		if( elms[i].id.match(m) )
			elms[i].style.display=''
		else
			elms[i].style.display='none'
	}

	elms = document.getElementsByClassName(tab_cls);
	m = '^.*' + id + '$'
	for (var i = 0; i < elms.length; i++)
	{
		if (elms[i].id.match(m))
			elms[i].style.background = "rgb(5, 147, 148)";
		else
			elms[i].style.background = "White";
	}
}

var VideoPathIdDivisor = 1000;
var ControlPathIdDivisor = 100000;

function extract_comp_id( id )
{
	var m = id.match( /(^.*)_([0-9]+)_(.*$)/ );
	if ( m )
		return { "prefix": m[1], "postfix": m[3], "info": ExtractIdInfo( m[2] ) };
	m = id.match( /(^.*)_([0-9]+)/ );
	if ( m )
		return { "prefix": m[1], "info": ExtractIdInfo( m[2] ) };
	m = id.match( /([0-9]+)_(.*$)/ );
		return { "postfix": m[2], "info": ExtractIdInfo( m[1] ) };
	return null;
}

function MakeCPId( prop )
{
	if ( typeof prop != "number" )
		prop -= 0;
	return ( ControlPathIdDivisor + prop );
}

function GetCPEl( prop )
{
	return document.getElementById( MakeCPId( prop ) );
}

function MakeId( vp, prop )
{
	if( typeof vp != "number" )
		vp -= 0;
	if ( typeof prop == "object" && prop.hasOwnProperty && prop.hasOwnProperty("propertyId") )
	{
		var ret = "";
		if( prop.hasOwnProperty( "prefix" ) )
			ret = prop.prefix + "_";
		ret += ( ( vp * VideoPathIdDivisor ) + ( prop.propertyId - 0 ) )
		if( prop.hasOwnProperty( "postfix" ) )
			ret += "_" + prop.postfix;
		return ret;
	}
	if ( typeof prop != "number" )
		prop -= 0;
	return ( ( vp * VideoPathIdDivisor ) + prop );
}

function GetEl( vp, prop )
{
	return document.getElementById( MakeId( vp, prop ) );
}

var CtrlProps =
{
	ID_OP_1080P50 : 10,
	ID_OP_1080P60 : 11,
	ID_OP_720P50 : 12,
	ID_OP_720P60 : 13,
	ID_STATUS_OVERLAY_EN : 20,
	ID_VPIDS : 50,
	ID_NO_ZOOM : 51,
	ID_NO_DEINT_SNAP : 52,
	ID_INP_CFG : 53,
	ID_KICK_ALL_PATHS : 54,
	ID_GET_BW : 55,
	ID_DYNAMIC_BW : 56,
	ID_START_TIME : 57,
	ID_GET_TPGLIST : 58,
	ID_GET_STATUS : 99
};

var Props =
{
//	ID_IN_PORT : 0,
	ID_IN_HDMI1 : 1, // indirect
	ID_IN_HDMI2 : 2, // indirect
	ID_IN_SDI1 : 3, // indirect
	ID_IN_SDI2 : 4, // indirect
	ID_IN_FORMAT_X : 5,
	ID_IN_FORMAT_Y : 6,
	ID_IN_FRAME_RATE : 7,
	ID_IN_COLOURSPACE : 8,
	ID_IN_SDI3 : 9, // indirect
	ID_IN_SDI4 : 10, // indirect
	ID_IN_EYE : 11, // indirect
	ID_IN_TPG : 12, // indirect

	ID_DEINT_ENABLE : 21,
	ID_DEINT_HUNTIING : 22,
	ID_DEINT_DETECT_32 : 23,
	ID_DEINT_DETECT_22 : 24,
	ID_DEINT_SHOW_MOTION : 25,
	ID_DEINT_SHOW_ANGLES : 26,
	ID_DEINT_PSF_MODE : 27,
	ID_DEINT_USE_MOTION : 28,
	ID_DEINT_USE_ANGLES : 29,
	ID_DEINT_MODE : 30,
//	ID_DEINT_22_FIRSTFIELD : 31,

	ID_SCALER_BPFGAIN : 32,
	ID_SCALER_ALPHA2_PERCENT : 33,
	ID_SCALER_ALPHA_PERCENT : 34,

//	ID_SCALER_ENABLE : 41,
	ID_SCALER_OFFSET_X : 42,
	ID_SCALER_OFFSET_Y : 43,
	ID_SCALER_IN_X : 44,
	ID_SCALER_IN_Y : 45,
	ID_SCALER_OUT_X : 46,
	ID_SCALER_OUT_Y : 47,
	ID_SCALER_TAPS_X : 48,
	ID_SCALER_TAPS_Y : 49,
	ID_SCALER_ALPHA_RAW_X : 50,
	ID_SCALER_ALPHA_RAW_Y : 51,
	ID_SCALER_ALPHA_ACTIVE_X : 52,
	ID_SCALER_ALPHA_ACTIVE_Y : 53,
	ID_SCALER_ALPHA_PERCENT_X : 54,
	ID_SCALER_ALPHA_PERCENT_Y : 55,
	ID_SCALER_ALPHA_OVERRIDE_X : 56,
	ID_SCALER_ALPHA_OVERRIDE_Y : 57,
	ID_SCALER_GAUSS : 58,
	ID_SCALER_TAPS_MAX_X : 59,
	ID_SCALER_TAPS_MAX_Y : 60,
	
	ID_OSD_ENABLE : 61,
	ID_OSD_OFFSET_X : 62,
	ID_OSD_OFFSET_Y : 63,
	ID_OSD_ALPHA : 64,
	ID_OSD_ZPLANE : 65,

	ID_FREEZE : 71,
	ID_OVERLAY_EN : 72,

	ID_WIN_IN_X : 80, // not currently used, these are for cropping...
	ID_WIN_IN_Y : 81, // not currently used, these are for cropping...
	ID_WIN_IN_W : 82, // not currently used, these are for cropping...
	ID_WIN_IN_H : 83, // not currently used, these are for cropping...

	ID_WIN_OUT_X : 90,
	ID_WIN_OUT_Y : 91,
	ID_WIN_OUT_W : 92,
	ID_WIN_OUT_H : 93,
	ID_WIN_OUT_SUPPRESS_PROGR : 94
};



function ExtractIdInfo( val )
{
	var prop = 0;
	var vp = 0;
	var cp = false;
	// turn it into an integer...
	val -= 0;
	if ( val >= ControlPathIdDivisor )
	{ // Control Path command
		prop = val - ControlPathIdDivisor;
		cp = true;
	}
	else
	{ // Video Path command
		vp = Math.floor( val / VideoPathIdDivisor );
		prop = val % VideoPathIdDivisor;
	}
	return { "isControlPath": cp, "videoPathId": vp, "propertyId": prop };
}


function default_handling( info, elm, value )
{
	if ( ! elm )
		return;

	switch ( elm.tagName )
	{
		case 'LABEL':
		{
			elm.innerHTML = vals[1];
			break;
		}
		case "INPUT":
		{
			if (elm.type == "radio" || elm.type == "checkbox" )
			{
				if (vals[1] == "1")
					elm.checked = true;
				else
					elm.checked = false;
			}
			if ( elm.type == "text" )
				elm.value = vals[1] + '%';
			break;
		}
		default:
			//alert( element.tagName )
			break;
	}
}

var rtveStartTime = 0;
//*******************************************************
// Decodes the incoming status update from the RTVE and pushes
// all values to the target fields
//********************************************************
function status_update(msg)
{
	if ( msg == null || msg == '' )
		return;
	msg = msg.replace(/&\s*$/g, '');
	var opts = msg.split("&");
	var len = opts.length;
	var screen_event = 0;
	for( var i = 0 ; i < opts.length; i++ )
	{
		vals = opts[i].split("=")
		var info = ExtractIdInfo( vals[0] );
		var propElm = document.getElementById( vals[0] );

		if ( info.isControlPath )
		{
			switch( info.propertyId )
			{
				case CtrlProps.ID_START_TIME:
				{
					if ( rtveStartTime == vals[1] )
						break;
					if ( rtveStartTime != 0 )
						location.reload();
					rtveStartTime = vals[1];
					break;
				}
				case CtrlProps.ID_VPIDS:
				{
					if ( inputs.length != 0 )
						break;
					possible_inputs = vals[1].replace(/_$/, '').split('_')
					for ( inp in possible_inputs )
						if ( inputs.indexOf( possible_inputs[inp] ) == -1 )
							addNewVP( possible_inputs[inp] )
					select_layoutset( inputs.length );
					break;
				}
				case CtrlProps.ID_NO_ZOOM:
				{
					var hs='auto';
					if ( vals[1] == 1 )
						hs = 'none';
					for ( var num = 0; num < inputs.length ; num++ )
						document.getElementById( 'screen_in_row' + inputs[num] ).style.display = hs;
					break;
				}
				case CtrlProps.ID_GET_BW:
				{
					if ( propElm )
						propElm.innerHTML = "" + ( ( vals[1] - 0 ) / 1000 ) + " GB/s";
					break;
				}
				case CtrlProps.ID_INP_CFG:
				{
					var addTPG = false;
					var p = JSON.parse(vals[1]);
					if ( p.input_sources )
					{
						for ( var num = 0; num < inputs.length ; num++ )
						{
							var thisinp = document.getElementById( "source_inner" + inputs[num] );
							if( !document.getElementById( "source_form" + inputs[num] ) )
							{
								var newinputs = '';
								for( var is = 0; is < p.input_sources.length; is++ )
								{
									var inpsrcid = MakeId( inputs[num], p.input_sources[is].html_id );
									if( p.input_sources[is].html_id == Props.ID_IN_TPG )
										addTPG = true;
									newinputs += '<div class="section_row' + ( newinputs == '' ? ' section_row_first' : '' ) + '"><div class="section_row_label">' + p.input_sources[is].label.replace( /\r?\n|\r/g, '') + '</div><div class="section_row_data"><input type="radio" id="' + inpsrcid + '" onclick="props_setparam( ' + inputs[num] + ', ' + p.input_sources[is].html_id + ', this.checked, true );" /></div></div>';
								}

								if ( thisinp.children.length > 0 )
									thisinp.children[0].className = thisinp.children[0].className.replace( /section_row_first/, ''  );

								newinputs += "</form>" + thisinp.innerHTML;
								thisinp.innerHTML = '<form id="source_form' + inputs[num] +'" action="">' + newinputs;
							}
						}
					}
					if ( addTPG )
					{
						addTestPatternGenerator();
					}
					break;
				}
				default:
				{
					default_handling( info, propElm, vals[1] );
					break;
				}
			}
		}
		else
		{
			switch( info.propertyId )
			{
				case Props.ID_WIN_IN_X:
				case Props.ID_WIN_IN_Y:
				case Props.ID_WIN_IN_W:
				case Props.ID_WIN_IN_H:
				case Props.ID_WIN_OUT_X:
				case Props.ID_WIN_OUT_Y:
				case Props.ID_WIN_OUT_W:
				case Props.ID_WIN_OUT_H:
				{
					screen_event = 1;
					host_screen[ MakeId( info.videoPathId, info.propertyId ) ] = vals[1];
					break;
				}
				case Props.ID_OSD_ZPLANE:
				{
					var dragging = false;
					for ( var b = 0; b < inputs.length; b++ )
						dragging |= boxOut[inputs[b]].IsDragging();
					if ( ! dragging )
						boxOut[ info.videoPathId ].GetContainer().style.zIndex = vals[1];
					default_handling( info, propElm, vals[1] );
					break;
				}
				case Props.ID_SCALER_ALPHA_RAW_X:
				case Props.ID_SCALER_ALPHA_RAW_Y:
				case Props.ID_SCALER_ALPHA_ACTIVE_X:
				case Props.ID_SCALER_ALPHA_ACTIVE_Y:
				case Props.ID_SCALER_ALPHA_OVERRIDE_X:
				case Props.ID_SCALER_ALPHA_OVERRIDE_Y:
				{
					if ( propElm )
						propElm.innerHTML = vals[1] / 100.0;
					break;
				}
				case Props.ID_SCALER_ALPHA_PERCENT:
				{
					if ( propElm )
						propElm.innerHTML = vals[1] / 100.0;
					break;
				}
				default:
				{
					default_handling( info, propElm, vals[1] );
					break;
				}
			}
		}
	}
	update_styles(screen_event);
}

function update_screen(id,sx,sy,x,y,w,h)
{
	id.SetXQuiet(percent(x,sx));
	id.SetYQuiet(percent(y,sy));
	id.SetCurrentWidthQuiet(percent(w,sx)+5);
	id.SetCurrentHeightQuiet(percent(h,sy)+5);
}

function setOpacity(e,v)
{
	e.style.opacity = v;
	e.style.filter = 'alpha(opacity=' + v*100 + ')';
}

//*******************************************************
// Given the local states of things, hide/visible certain
// things to reflect what can be done at the momemnt
//********************************************************
function update_styles(screen)
{
	for ( var i = 0; i < inputs.length; i++ )
	{
		var id = parseInt(inputs[i]);
		if (screen)
		{ // Move the onscreen widgets around.
			update_screen( boxIn[id], 200,100,host_screen[MakeId( id, Props.ID_WIN_IN_X )], host_screen[MakeId( id, Props.ID_WIN_IN_Y )], host_screen[MakeId( id, Props.ID_WIN_IN_W )], host_screen[MakeId( id, Props.ID_WIN_IN_H )]);
			update_screen( boxOut[id],400,200,host_screen[MakeId( id, Props.ID_WIN_OUT_X )], host_screen[MakeId( id, Props.ID_WIN_OUT_Y )], host_screen[MakeId( id, Props.ID_WIN_OUT_W )], host_screen[MakeId( id, Props.ID_WIN_OUT_H )]);
		}

		if ( GetEl( id, Props.ID_IN_FRAME_RATE).innerHTML == "-")
		{ // are inputs missing
			document.getElementById(id+"_snapshot").disabled = true;
			setOpacity( document.getElementById("osd"+id),0.2 );
			setOpacity( document.getElementById("deint"+id),0.2 );
			setOpacity( document.getElementById("scale"+id),0.2 );
			if ( boxOut[id].GetContainer().style.visibility != 'hidden' )
				boxIn[id].SetImage("images/vp"+id+"_missing.bmp");
			boxOut[id].GetContainer().style.visibility = 'hidden';
		}
		else
		{
			setOpacity(document.getElementById("osd"+id),1);
			if ( document.getElementById(id+"_snapshot").disabled != false )
				boxIn[id].SetImage("images/vp"+id+".bmp");
			document.getElementById(id+"_snapshot").disabled = false;
			// Input Present, but is this VP turned on?
			if ( GetEl( id, Props.ID_OSD_ENABLE ).checked == false )
			{
				boxOut[id].GetContainer().style.visibility = 'hidden';
				setOpacity(document.getElementById("deint"+id),0.2);
				setOpacity(document.getElementById("scale"+id),0.2);
			}
			else
			{
				boxOut[id].GetContainer().style.visibility = '';
				if (GetEl( id, Props.ID_IN_FRAME_RATE).innerHTML.search("i") == -1)
					setOpacity(document.getElementById("deint"+id),0.2);
				else
					setOpacity(document.getElementById("deint"+id),1);
				setOpacity(document.getElementById("scale"+id),1);
			}
		}

		if ( send_active == 0 )
		{
			if ( ! trackbar_osd_alpha[id].IsDragging() )
				trackbar_osd_alpha[id].SetCurrentValue( parseInt( GetEl( id, Props.ID_OSD_ALPHA).innerHTML ) );

			if ( ! trackbar_scaler_alpha[id].IsDragging() )
				trackbar_scaler_alpha[id].SetCurrentValue( parseFloat( GetEl( id, Props.ID_SCALER_ALPHA_PERCENT ).innerHTML) * 100 );
		}
		
		var full_taps = parseInt( GetEl( id, Props.ID_SCALER_TAPS_X ).innerHTML );
		var restrict_taps = parseInt( GetEl( id, Props.ID_SCALER_TAPS_MAX_X ).innerHTML );

		if ( restrict_taps > full_taps )
			document.getElementById(id + "_active_taps_h" ).innerHTML = full_taps;
		else
			document.getElementById(id + "_active_taps_h" ).innerHTML = restrict_taps;

		full_taps = parseInt( GetEl( id, Props.ID_SCALER_TAPS_Y ).innerHTML );
		restrict_taps = parseInt( GetEl( id, Props.ID_SCALER_TAPS_MAX_Y ).innerHTML );

		if ( restrict_taps > full_taps )
			document.getElementById(id + "_active_taps_v" ).innerHTML = full_taps;
		else
			document.getElementById(id + "_active_taps_v" ).innerHTML = restrict_taps;
	}
}

//*******************************************************
//* Used for mobile internet browsers to convert touch into
//* mouse operation... (NOT Working completely yet)
//********************************************************
function touchHandler(event)
{
	var touches = event.changedTouches, first = touches[0], type = "";
	switch(event.type)
	{
		case "touchstart": type = "mousedown"; break;
		case "touchmove": type = "mousemove"; break;
		case "touchend": type = "mouseup"; break;
		default: return;
	}
	var simulatedEvent = document.createEvent("MouseEvent");
	simulatedEvent.initMouseEvent(type, true, true, window, 1, first.screenX, first.screenY, first.clientX, first.clientY, false, false, false, false, 0/*left*/, null);
	first.target.dispatchEvent(simulatedEvent);
	var target = event.target;
	if( target.className == 'rtImgArea' || target.className == 'draggable' || target.className == 'rtBottomHandle' || target.className == 'rtCorner' || target.className == 'rtImgArea' || target.className == 'rtRightHandle' || target.className == 'rtTopCorner' || target.className == 'trackbar_class' || target.name == "notouch" )
	{
		event.preventDefault();
	}
}

//*******************************************************
//* Hook into mobile events
//********************************************************
function init_mobile_device()
{
	if (document.addEventListener)
	{
		document.addEventListener( "touchstart", touchHandler, true);
		document.addEventListener( "touchmove", touchHandler, true);
		document.addEventListener( "touchend", touchHandler, true);
		document.addEventListener( "touchcancel", touchHandler, true);
	}
}



function setup()
{
	// patch the static html to have control path ids...
	var allElements = document.getElementsByTagName('*');
	for( var elmidx in allElements )
	{
		var elm = allElements[elmidx];
		var an = null;
		if ( elm.getAttribute && elm.getAttribute("onclick" ) )
			an = elm.getAttribute("onclick" );
		if( !an && elm.getAttributeNode && elm.getAttributeNode("onclick") )
			an = elm.getAttributeNode("onclick").value;
		if ( an && an.match( /props_setsystem/ ) )
		{
			var ctrlprop = an.match( /CtrlProps\.[^, ]*/ );
			if( ctrlprop )
			{
				ctrlprop = eval( ctrlprop[0] );
				elm.id = MakeCPId( ctrlprop );
			}
		}
	}
	var elm = document.getElementById("ID_GET_BW");
	if ( elm )
		elm.id = MakeCPId( eval( "CtrlProps." + elm.id ) )
	// end patch

	init_mobile_device();
	setInterval(props_poll,1000);
	props_poll();
}

function addNewVP( vpId )
{
	var _vp = document.getElementById("_vp");
	var _system = document.getElementById("_system");
	var _nstabs = document.getElementById("_tab_head");
	var _nstab_body = document.getElementById("_tab_body");

	inputs.push( vpId );
	build_vp_layout( _system, vpId );
	add_nstab( _nstabs, vpId );
	add_nstab_body( _nstab_body, vpId );

	if (inputs.length > 1)
		document.getElementById('tab_body_' + vpId).style.display = 'none'
	else
		document.getElementById('tab_tab_' + vpId).style.background = 'rgb(5, 147, 148)'
}

function change_trackbar( vp, prop, val )
{
	GetEl( vp, prop ).innerHTML = val;
	props_setparam( vp, prop, val,1);
}

function change_trackbar_comp( vp, idinfo, val )
{
	GetEl( vp, idinfo ).innerHTML = val;
	val = idinfo.postfix.substring(0,3) + "_" + val;
	props_setparam( vp, idinfo.propertyId, val, true, true );
}

function change_trackbar_float( vp, prop, val, div )
{
	GetEl( vp, prop ).innerHTML = ( val / div );
	props_setparam( vp, prop, val,1);
}

function move_focus( id )
{
	if ( send_pending > 0 )
		return;

	var max_id = inputs.length - 1;
	var selectedElm = boxOut[id].GetContainer()

	for ( var i = 0; i < inputs.length; i++ )
	{
		if ( boxOut[inputs[i]].GetContainer().style.zIndex > selectedElm.style.zIndex )
		{
			boxOut[inputs[i]].GetContainer().style.zIndex--;
			props_setparam( inputs[i], Props.ID_OSD_ZPLANE, boxOut[inputs[i]].GetContainer().style.zIndex, false );
		}
	}
	selectedElm.style.zIndex = max_id;
	props_setparam( id, Props.ID_OSD_ZPLANE, selectedElm.style.zIndex, true );
	toggle_body( id , 'tab_body', 'tab_tab' )
}


function get_style( id, style )
{
	var elm = document.getElementById( id );
	if ( ! elm )
		return null;
	if( document.defaultView )
		return document.defaultView.getComputedStyle( elm, "" ).getPropertyValue( style );
	return null;
}

function build_vp_layout( _system, id )
{
	var layout = document.createElement('div');
	layout.className = 'layoutdiv';
	layout.id = 'layout_' + id;

	var ihtml = '<div style="border-bottom:solid 1px rgb(5, 147, 148); padding-bottom:5px;">';
	ihtml += '<div class="section2_hdr">Input Video ' + id + ' Layout</div>';

	ihtml += '<div class="section_row section_row_first">';
	ihtml += '<div class="section_row_label section_row_label2">Freeze Image</div>';
	ihtml += '<div class="section_row_data">';
	ihtml += '<input type="checkbox" id="' + MakeId( id, Props.ID_FREEZE ) + '" onclick="props_setparam( ' + id + ', Props.ID_FREEZE, this.checked, true );" />';
	ihtml += '</div>';
	ihtml += '</div>';

	ihtml += '<div class="section_row">';
	ihtml += '<div class="section_row_label section_row_label2">Show Text Overlay</div>';
	ihtml += '<div class="section_row_data">';
	ihtml += '<input type="checkbox" id="' + MakeId( id, Props.ID_OVERLAY_EN) +'" onclick="props_setparam( ' + id + ', Props.ID_OVERLAY_EN, this.checked, true );" />';
	ihtml += '</div>';
	ihtml += '</div>';

	ihtml += '<div class="section_row"><div><button class="button" id="' + id + '_snapshot" type="button" onclick="window.open( \'' + host_override + '/vps' + id + '.bmp\');">Snapshot</button></div></div>';
	ihtml += '<div class="section_row" id="screen_in_row'+id+'" style="display: none;"><div class="section_row_label"><div id="screen_in' + id + '" class="draggable" style="background-color:#C0C0C0;position:relative;width:200px;height:100px;border:5px solid black;"></div></div></div>';
	ihtml += '</div>';

	layout.innerHTML = ihtml;
	_system.appendChild( layout );

	boxIn[id] = new ResizeableImgbox( 'In' + id, './images/vp'+id+'.bmp', 'screen_in'+id, 205, 105,
									function( x,y,width,height )
									{
										props_setparam( id, Props.ID_WIN_IN_X, scale_percent(x,200),0);
										props_setparam( id, Props.ID_WIN_IN_Y, scale_percent(y,100),0);
										props_setparam( id, Props.ID_WIN_IN_W, scale_percent(width-5,200),0);
										props_setparam( id, Props.ID_WIN_IN_H, scale_percent(height-5,100),1);
									}
							);

	boxOut[id] = new ResizeableImgbox( 'Out' + id, './images/vp'+id+'.bmp', 'screen', 205, 105,
									function(x,y,width,height)
									{
										props_setparam( id, Props.ID_WIN_OUT_X, scale_percent(x,400),0);
										props_setparam( id, Props.ID_WIN_OUT_Y, scale_percent(y,200),0);
										props_setparam( id, Props.ID_WIN_OUT_W, scale_percent(width-5,400),0);
										props_setparam( id, Props.ID_WIN_OUT_H, scale_percent(height-5,200),1);
									},
									function()
									{
										move_focus(id);
									},
									function()
									{
										props_setparam( id, Props.ID_WIN_OUT_SUPPRESS_PROGR, 1,1);
									},
									function()
									{
										props_setparam( id, Props.ID_WIN_OUT_SUPPRESS_PROGR, 0,1);
									}
							);

	boxIn[id].SetMaxWidth( parseInt( get_style( "screen_in" + id, "width" ) ) + 5 );
	boxIn[id].SetMaxHeight( parseInt( get_style( "screen_in" + id, "width" ) ) + 5 );
	boxIn[id].SetXQuiet( 0 );
	boxIn[id].SetYQuiet( 0 );
	boxOut[id].SetMaxWidth( parseInt( get_style( "screen", "width") ) + 5 );
	boxOut[id].SetMaxHeight( parseInt( get_style( "screen", "height" ) ) + 5 );
	boxOut[id].SetXQuiet( 0 );
	boxOut[id].SetYQuiet( 0 );
	for ( var i = 0;i < inputs.length; i++ )
	{
		if ( inputs[i] == id )
		{
			boxOut[id].GetContainer().style.zIndex = i;
			break;
		}
	}
}

function add_nstab( _tabs, id )
{
	_tabs.innerHTML += '<div class="tab_tab" id="tab_tab_' + id + '" onClick="toggle_body( ' + id + ', \'tab_body\', \'tab_tab\' )">' + id + '</div>';
}

function toggle_section(id, toggler)
{
	var el = document.getElementById( id )
	if ( el.style.display == 'none' || el.style.display == null )
	{
		el.style.display = 'block';
		toggler.innerHTML = "Hide";
	}
	else
	{
		el.style.display = 'none';
		toggler.innerHTML = "Show";
	}
}

function kick_paths()
{
	props_setsystem( CtrlProps.ID_KICK_ALL_PATHS, 1);
}

function change_scaler_max_taps( id, dir )
{
	var el = GetEl( id, dir );
	var val = parseFloat( window.prompt("Enter new Max Taps. 99 or more for no restriction", parseInt(el.innerHTML)) );
	if ( val == null || isNaN( val ) )
		alert( "Invalid value, please enter an integer. 99 or more for no restriction." );
	else
	{
		el.innerText = val;
		props_setparam( id, dir, val,1);
	}
}

function tbar_alert_float( vp, prop, text, tbar, div )
{
	var el = GetEl( vp, prop );
	var val = parseFloat( window.prompt(text, parseFloat(el.innerHTML) ) );
	if( val == null || isNaN( val )|| val < ( tbar.GetMinValue() / div ) || val > ( tbar.GetMaxValue() / div ) )
	{
		alert( "Invalid value " + val + ", it must be a value between " + ( tbar.GetMinValue() / div ) + " and " + ( tbar.GetMaxValue() / div ) );
	}
	else
	{
		el.innerText = parseInt( val * div ) / div;
		props_setparam( vp, prop, parseInt( val * div ), true );
		tbar.SetCurrentValue( parseInt( val * div ) );
	}
}

function tbar_alert( vp, prop, text, tbar )
{
	var el = GetEl( vp, prop );
	var val = parseInt( window.prompt(text, parseInt(el.innerHTML) ) );
	if( val == null || isNaN( val ) || val < tbar.GetMinValue() || val > tbar.GetMaxValue() )
	{
		alert( "Invalid value " + val + ", it must be an integer between " + tbar.GetMinValue()+ " and " + tbar.GetMaxValue() );
	}
	else
	{
		el.innerText = val;
		props_setparam( vp, prop, val, true );
		tbar.SetCurrentValue( val );
	}
}

function tbar_alert_comp( el, text, tbar )
{
	var val = parseInt( window.prompt(text, parseInt(el.innerHTML) ) );
	if( val == null || isNaN( val ) || val < tbar.GetMinValue() || val > tbar.GetMaxValue() )
	{
		alert( "Invalid value " + val + ", it must be an integer between " + tbar.GetMinValue()+ " and " + tbar.GetMaxValue() );
	}
	else
	{
		var idinfo = extract_comp_id( el.id );
		if ( idinfo && !idinfo.info.isControlPath && idinfo.postfix )
		{
			el.innerText = val;
			tbar.SetCurrentValue( val );
			val = idinfo.postfix.substring(0,3) + "_" + val;
			props_setparam( idinfo.info.videoPathId, idinfo.info.propertyId, val, true, true );
		}
	}
}

function motion_toggle( id )
{
	if ( GetCPEl( CtrlProps.ID_DYNAMIC_BW ).checked == false )
	{
		props_setparam( id , Props.ID_DEINT_USE_MOTION, GetEl( id , Props.ID_DEINT_USE_MOTION ).checked, true );
		return true;
	}
	else
	{
		alert("To override this please uncheck \"Dynamic Bandwidth\" first");
		return false;
	}
}

function collapsible_section(id, name, title)
{
	var m_id = id;
	var m_name = name;
	var m_title = title;
	var row = []

	this.construct = function()
	{
		ihtml = "";
		ihtml += '<div id="' + m_name + m_id + '">';
		ihtml += '<div class="section2_hdr">' + m_title + ' <div class="hs_div" onclick="toggle_section(\'' + m_name + '_inner' + m_id + '\', this)">Show</div></div>';
		ihtml += '<div id="' + m_name + '_inner' + m_id + '" style="display: none;">';
		var i;
		for ( i = 0; i < row.length; i++ )
		{
			ihtml += '<div class="section_row';
			if ( i == 0 )
				ihtml+= ' section_row_first';
			if ( i == row.length - 1 )
				ihtml+= ' section_row_last';
			ihtml += '">';
			ihtml += row[i];
			ihtml += '</div>';
		}
		ihtml += '</div>';
		ihtml += '</div>';
		return ihtml;
	}

	this.addRow = function(rowinner)
	{
		row.push( rowinner );
	}

	this.addTickBoxRow = function( label, partId, func )
	{
		if ( func == undefined )
			func = 'props_setparam( ' + m_id + ', ' + partId + ', this.checked, 1 );';
		this.addRow('<div class="section_row_label">' + label + '</div><div class="section_row_data"><input type="checkbox" id="' + this.formId( partId ) + '" onclick="' + func + '" /></div>');
	}

	this.addBoxRow = function( label, partId, value, onclick )
	{
		var oc="";
		if( onclick )
			oc=' onclick="' + onclick + '"';
		this.addRow( '<div class="section_row_label">' + label + '</div><div class="section_row_data"><label class="label_data2" id="' + this.formId( partId ) + '"' + oc + '>' + value + '</label></div>');
	}

	this.addDoubleBoxRow = function( label, partId1, partId2, value1, value2, onclick1, onclick2 )
	{
		var ihtml = '<div class="section_row_label">' + label + '</div><div class="section_row_data">'

		ihtml += '<label class="label_data1" id="' + this.formId( partId1 ) + '"';
		if ( onclick1 != undefined )
			ihtml += ' onclick="' + onclick1 + '"';
		ihtml += '>' + value1 + '</label>';

		ihtml += '<label class="label_data1" id="' + this.formId( partId2 ) + '"'
		if ( onclick2 != undefined )
			ihtml += ' onclick="' + onclick2 + '"';
		ihtml += '>' + value2 + '</label>';

		ihtml += '</div>';

		this.addRow( ihtml );
	}

	this.addTrackbarRow = function( label, tbid )
	{
		this.addRow( '<div class="section_row_label" name="notouch">' + label + '</div><div class="section_row_data" name="notouch"><div class="trackbar_class" id="' + tbid + '_' + m_id + '"></div></div>' );
	}

	this.formId = function( partId )
	{
		if ( typeof partId == "number" )
		{
			return ( ( m_id * VideoPathIdDivisor ) + partId );
		}
		else if ( typeof partId == "string" )
		{
			return m_id + partId;
		}
		else if ( typeof partId == "object" && partId.hasOwnProperty && partId.hasOwnProperty("propertyId") )
		{
			var ret = "";
			if( partId.hasOwnProperty( "prefix" ) )
				ret = partId.prefix + "_";
			ret += ( ( m_id * VideoPathIdDivisor ) + ( partId.propertyId - 0 ) )
			if( partId.hasOwnProperty( "postfix" ) )
				ret += "_" + partId.postfix;

			return ret;
		}
		return "";
	}
}

function add_nstab_body( _vp, id )
{
	var this_vp = document.createElement('div');

	this_vp.id = 'tab_body_'+id
	this_vp.className="tab_body"

	ihtml = '<div class="section">';

	var source = new collapsible_section( id, "source", "Input Source" );
	source.addDoubleBoxRow( "Format", Props.ID_IN_FORMAT_X, Props.ID_IN_FORMAT_Y, 1920, 1080 );
	source.addBoxRow( "Frame Rate", Props.ID_IN_FRAME_RATE, "50i" );
	source.addBoxRow( "Colour Space", Props.ID_IN_COLOURSPACE, "YUV" );
	ihtml += source.construct();

	var deint = new collapsible_section( id, 'deint', 'Deinterlacer' );
	deint.addBoxRow( "Mode", Props.ID_DEINT_MODE, "Motion + Angles" );
	deint.addTickBoxRow( "Enable", Props.ID_DEINT_ENABLE);
	deint.addTickBoxRow( "PsF Mode", Props.ID_DEINT_PSF_MODE );
	deint.addTickBoxRow( "Use Motion", Props.ID_DEINT_USE_MOTION, 'return motion_toggle( ' + id + ' );' );
	deint.addTickBoxRow( "Use Angles", Props.ID_DEINT_USE_ANGLES );
	deint.addTickBoxRow( "Show Motion", Props.ID_DEINT_SHOW_MOTION );
	deint.addTickBoxRow( "Show Angles", Props.ID_DEINT_SHOW_ANGLES );
	deint.addBoxRow( "Pulldown", Props.ID_DEINT_HUNTIING, "Hunting" );
	deint.addTickBoxRow( "Detect 3:2", Props.ID_DEINT_DETECT_32 );
	deint.addTickBoxRow( "Detect 2:2", Props.ID_DEINT_DETECT_22 );
	ihtml += deint.construct();

	var scaler = new collapsible_section( id, 'scale', 'Scaler' );
	scaler.addDoubleBoxRow("Input Offset", Props.ID_SCALER_OFFSET_X, Props.ID_SCALER_OFFSET_Y, 0, 0 );
	scaler.addDoubleBoxRow("Input Size", Props.ID_SCALER_IN_X, Props.ID_SCALER_IN_Y, 1920, 1080 );
	scaler.addDoubleBoxRow("Output Size", Props.ID_SCALER_OUT_X, Props.ID_SCALER_OUT_Y, 1920, 1080 );
	scaler.addDoubleBoxRow("Available Taps", Props.ID_SCALER_TAPS_X, Props.ID_SCALER_TAPS_Y, 8, 8 );
	scaler.addDoubleBoxRow("Max Taps", Props.ID_SCALER_TAPS_MAX_X, Props.ID_SCALER_TAPS_MAX_Y, 0, 0, 'change_scaler_max_taps(' + id + ', Props.ID_SCALER_TAPS_MAX_X);', 'change_scaler_max_taps(' + id + ', Props.ID_SCALER_TAPS_MAX_Y);' );
	scaler.addDoubleBoxRow( "ActiveTaps", "_active_taps_h", "_active_taps_v", 0, 0 );

	scaler.addDoubleBoxRow( "Raw Alpha", Props.ID_SCALER_ALPHA_RAW_X, Props.ID_SCALER_ALPHA_RAW_Y, 0, 0 );
	scaler.addDoubleBoxRow( "Active Alpha", Props.ID_SCALER_ALPHA_ACTIVE_X, Props.ID_SCALER_ALPHA_ACTIVE_Y, 0, 0 );
	scaler.addBoxRow( "LPF % Adjust", Props.ID_SCALER_ALPHA_PERCENT, "0", "tbar_alert_float("+id+","+Props.ID_SCALER_ALPHA_PERCENT+",'Enter new value',trackbar_scaler_alpha["+id+"], 100)" );
	scaler.addTrackbarRow( "", "trackbar_scaler_alpha" );

	ihtml += scaler.construct();

	var osd = new collapsible_section( id, 'osd', 'OSD' );
	osd.addTickBoxRow( "Enable", Props.ID_OSD_ENABLE );
	osd.addDoubleBoxRow( "Screen Offset", Props.ID_OSD_OFFSET_X, Props.ID_OSD_OFFSET_Y, 0, 0 );
	osd.addBoxRow( "Alpha Blend %", Props.ID_OSD_ALPHA, "0", "tbar_alert("+id+","+Props.ID_OSD_ALPHA+",'Enter new value',trackbar_osd_alpha["+id+"])" );
	osd.addTrackbarRow( "", "trackbar_osd_alpha" );
	osd.addBoxRow( "Z-Plane", Props.ID_OSD_ZPLANE, "" );
	ihtml += osd.construct();

	ihtml += "</div>"

	this_vp.innerHTML = ihtml;
	_vp.appendChild( this_vp );
	// first box needs this...
	this_vp.children[0].children[0].children[0].style.borderTopWidth = "5px";

	trackbar_osd_alpha[id] = new Trackbar(0, 100, 100, function( val ) { change_trackbar( id, Props.ID_OSD_ALPHA, val ); } );
	document.getElementById( "trackbar_osd_alpha_" + id ).appendChild( trackbar_osd_alpha[id].GetContainer() );

	trackbar_scaler_alpha[id] = new Trackbar( -10000, 10000, 100, function( val ) { change_trackbar_float( id, Props.ID_SCALER_ALPHA_PERCENT, val, 100 ); } );
	document.getElementById( "trackbar_scaler_alpha_" + id ).appendChild( trackbar_scaler_alpha[id].GetContainer() );
}



function addTestPatternGenerator()
{
	var d = document.createElement('div');

	d.className = "section tpg_section";
	d.innerHTML = '<div class="section_hdr">Test Patten Generator <div class="tpg_refresh_div" onclick="get_commandpath( CtrlProps.ID_GET_TPGLIST, handle_tpglist )">Refresh</div></div><div><select id="'+CtrlProps.ID_GET_TPGLIST+'" size="4" onclick="props_setsystem( this.id, this.options[this.selectedIndex].value, true )"></select></div>';

	document.body.children[0].appendChild( d );
	get_commandpath( CtrlProps.ID_GET_TPGLIST, handle_tpglist );
}

function handle_tpglist( o )
{
	var elm = document.getElementById(CtrlProps.ID_GET_TPGLIST);
	elm.innerHTML = '';
	var filelist = JSON.parse( o.responseText );
	for( f in filelist.files )
	{
		var option = '<option name="' + filelist.files[f].filename + '"';
		if ( filelist.files[f].selected )
			option += ' selected';
		option += '>'+ filelist.files[f].filename +'</option>';
		elm.innerHTML += option;
	}
}
