

var layout_2x = [
//[ x, y, w, h, z, on  ]
  [ [ 0,   0,   50,  50,  1, true  ], [ 50,  0,   50,  50,  0, true  ], "Grid No Border" ],
  [ [ 2,   17,  66,  66,  1, true  ], [ 69,  2,   30,  30,  0, true  ], "2"  ],
  [ [ 17,  2,   66,  66,  1, true  ], [ 2,   69,  30,  30,  0, true  ], "3"  ],
  [ [ 0,   0,   50,  100, 1, true  ], [ 50,  0,   50,  100, 0, true  ], "3D Side-By-Side"  ],
  [ [ 0,   0,   100, 100, 0, true  ], [ 67,  3,   25,  25,  1, true  ], "5"  ],
  [ [ 2,   2,   47,  47,  1, true  ], [ 52,  2,   47,  47,  0, true  ], "Grid With Border"  ],
  [ [ 0,   0,   100, 100, 1, true  ], [ 67,  3,   25,  25,  0, false ], "7"  ],
];

var layout_4x = [
//[ x, y, w, h, z, on  ]
  [ [ 0,   0,   50,  50,  3, true  ], [ 50,  0,   50,  50,  2, true  ], [ 0,   50,  50,  50,  1,  true  ], [ 50,  50,  50,  50,  0,  true  ], "Grid No Border" ],
  [ [ 2,   17,  66,  66,  3, true  ], [ 69,  2,   30,  30,  2, true  ], [ 69,  35,  30,  30,  1,  true  ], [ 69,  68,  30,  30,  0,  true  ], "2"  ],
  [ [ 17,  2,   66,  66,  3, true  ], [ 2,   69,  30,  30,  2, true  ], [ 35,  69,  30,  30,  1,  true  ], [ 68,  69,  30,  30,  0,  true  ], "3"  ],
  [ [ 0,   0,   50,  100, 3, true  ], [ 50,  0,   50,  100, 2, true  ], [ 0,   50,  50,  50,  1,  false ], [ 50,  50,  50,  50,  0,  false ], "3D Side-By-Side"  ],
  [ [ 0,   0,   100, 100, 0, true  ], [  3,  67,  25,  25,  1, true  ], [ 38,  67,  25,  25,  2,  true  ], [ 72,  67,  25,  25,  3,  true  ], "5"  ],
  [ [ 2,   2,   47,  47,  3, true  ], [ 52,  2,   47,  47,  2, true  ], [ 2,   51,  47,  47,  1,  true  ], [ 52,  51,  47,  47,  0,  true  ], "Grid With Border"  ],
  [ [ 0,   0,   100, 100, 3, true  ], [ 67,  3,   25,  25,  1, false ], [ 67,  34,  25,  25,  2,  false ], [ 67,  67,  25,  25,  0,  false ], "7"  ],
];

var layout_6x = [
//[ x, y, w, h, z, on  ]
  [ [   2,   2,   64,  64,  5, true ], [  68,   2,  31,  31,  4, true ], [  68,  35,  31,  31,  3, true ], [  68,  68,  31,  31,  2, true ], [   2,  68,  31,  31,  1, true ], [  35,  68,  31,  31,  0, true ], "2" ],
  [ [  13,   2,   75,  75,  0, true ], [   2,  80,  15,  15,  1, true ], [  22,  80,  15,  15,  2, true ], [  42,  80,  15,  15,  3, true ], [  62,  80,  15,  15,  4, true ], [  82,  80,  15,  15,  5, true ], "4" ],
  [ [   2,  15,   31,  31,  5, true ], [  35,  15,  31,  31,  4, true ], [  68,  15,  31,  31,  3, true ], [   2,  55,  31,  31,  2, true ], [  35,  55,  31,  31,  1, true ], [  68,  55,  31,  31,  0, true ], "3 x 2" ],
  [ [  28,   2,   45,  45,  5, true ], [  28,  52,  45,  45,  4, true ], [   1,   9,  26,  26,  3, true ], [  74,   9,  26,  26,  2, true ], [   1,  60,  26,  26,  1, true ], [  74,  60,  26,  26,  0, true ], "3" ],
  [ [   0,   0,  100, 100,  0, true ], [   2,  80,  15,  15,  1, true ], [  22,  80,  15,  15,  2, true ], [  42,  80,  15,  15,  3, true ], [  62,  80,  15,  15,  4, true ], [  82,  80,  15,  15,  5, true ], "4" ],
  [ [  42,  50,   16,  16,  5, true ], [   5,  10,  35,  35,  4, true ], [  60,  10,  35,  35,  3, true ], [  17,  60,  20,  20,  2, true ], [  40,  70,  20,  20,  1, true ], [  62,  60,  20,  20,  0, true ], "Happy" ],
];


var layout = null;

var active_layout = 0;

function select_layoutset( paths )
{
    if ( paths <= 2 )
        layout = layout_2x;
    else if ( paths <= 4 )
        layout = layout_4x;
    else if ( paths <= 6 )
        layout = layout_6x;
    else
    {
        alert( "No suitable layouts..." );
        layout_buttons( true );
        return;
    }
    layout_buttons( false );
    active_layout = 0;
    reset_layout();
}

function layout_buttons( disable )
{
  document.getElementById("layout_prev_id").disabled = disable;
  document.getElementById("layout_next_id").disabled = disable;
  document.getElementById("layout_reset_id").disabled = disable;
}

function percent(v,range) {
  return parseInt( ( v / 100 ) * range );
}

function reset_layout() {
  update_layout( active_layout );
}

function prev_layout() {
  if ( active_layout == 0 )
    update_layout( layout.length - 1 );
   else
     update_layout( active_layout - 1 );
}

function next_layout() {

  if ( active_layout == layout.length - 1 )
    update_layout( 0 );
  else
     update_layout( active_layout + 1 );
}

function is_shrinking( lo, bo )
{
  if ( ( percent( lo[2], 400 ) + percent( lo[3], 200 ) ) < ( bo.GetCurrentWidth() + bo.GetCurrentHeight() ) )
    return true;
  return false;
}

function update_layout(i)
{
  active_layout = i;

  for ( var inp = 0; inp < layout[active_layout].length - 1; inp++ )
  {
    props_setparam( inputs[ inp ], Props.ID_OSD_ENABLE, false, false );
  }
  update_styles();

  for ( var inp = 0; inp < layout[active_layout].length - 1; inp++ )
  {
    var id_out = boxOut[ inputs[ inp ] ];
    id_out.SetX( percent( layout[active_layout][inp][0], 400 ) );
    id_out.SetY( percent( layout[active_layout][inp][1], 200 ) );
    id_out.SetCurrentWidth( percent( layout[active_layout][inp][2], 400 ) + 5 );
    id_out.SetCurrentHeight( percent( layout[active_layout][inp][3], 200 ) + 5 );

    change_trackbar( inputs[ inp], Props.ID_OSD_ALPHA, 100 );
    props_setparam( inputs[ inp ], Props.ID_OSD_ENABLE, layout[active_layout][inp][5], false );

    id_out.GetContainer().style.zIndex = layout[active_layout][inp][4];
    props_setparam( inputs[inp], Props.ID_OSD_ZPLANE, id_out.GetContainer().style.zIndex, false );
  }
  
  document.getElementById("id_layout").innerHTML = layout[active_layout][ layout[active_layout].length - 1 ];
  update_styles();
}
