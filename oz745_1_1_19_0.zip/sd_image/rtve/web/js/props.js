// Create the Global Property structures.
host_screen = new Array();

var first_time = 1;

var newSettings = {};
/*  Queue a property update */

function props_setsystem( prop, val, forceString)
{
  var setval = val - 0;
  if ( forceString )
    setval = val;
  newSettings.cp = {};
  newSettings.cp[prop] = setval;
  props_send();
}

function props_setparam(VideoInput, ParamId, Value,update, forceString)
{
  var val = Value - 0;
  if ( forceString )
    val = Value

  if ( VideoInput < 100 )
  {
    if ( ! newSettings.vp )
    {
      newSettings.vp = {};
      var i;
      for( i = 0; i < inputs.length; i++ )
      {
        newSettings.vp[inputs[i]] = { }
      }
    }
    newSettings.vp[VideoInput][ParamId] = val
  }
  else
  {
    alert( "Unhandled system param: " + ParamId );
    return;
  }

  // Shadow values in host screen.
  if (ParamId >= 80 && ParamId <= 99) {
    host_screen[ MakeId(VideoInput, ParamId) ] = Value;
  }
  
  if (update)
    props_send();
}

////////////////////////////////// POLL STATUS /////////////////////////////////////
 var poll_active = 0;

function props_poll() 
{
  var element = document.getElementById("connection_status");
  if (poll_active) {
    element.innerHTML = "No Connection to RTVE";
    element.style.color = "yellow";
    element.style.background = "red";
  }
  if (poll_active == 0 && send_active == 0) {
//    if (first_time)
      cmd = '/cmd/getallparams/';		
//    else
//      cmd = '/cmd/getparams/';		
    poll_active = '1';
    element.innerHTML = "Connected to RTVE";
    element.style.color = "yellow";
    element.style.background = "green";
    YAHOO.util.Connect.asyncRequest('POST', host_override + cmd, props_poll_callback);
  } 
}

var props_poll_success = function(o) {
  status_update(o.responseText);
  poll_active = 0;
}

var props_poll_failure = function(o) {
  //alert( "FAILURE..." );
  poll_active = 0;
}

var props_poll_callback =  
{
  success: props_poll_success,
  failure: props_poll_failure
};

////////////////////////////////// CMD DISPATCH /////////////////////////////////////
function props_send()
{
  var msg = '';
  
  if ( send_active == 1 ) {
    send_pending = send_pending + 1;
  } else {
    send_active = 1;
    //alert( JSON.stringify( newSettings ) )
    for ( var vp in newSettings.vp )
      for( var prop in newSettings.vp[vp] )
        msg += MakeId( vp, prop ) + "=" + newSettings.vp[vp][prop] + '&';
    if ( newSettings.cp )
      for( var prop in newSettings.cp )
        msg += MakeCPId( prop ) + "=" + newSettings.cp[prop] + '&';
    newSettings = {};
    cmd = '/cmd/setparams/' + msg;
    YAHOO.util.Connect.asyncRequest('POST', host_override + cmd, props_send_callback);
  }
}

var send_active = 0;
var send_pending = 0;
 
var props_send_success = function(o) {
  status_update(o.responseText);
  first_time = 0;
  send_active = 0;
  if (send_pending != 0) {
    send_pending = 0;
    props_send();
  }   
}

var props_send_failure = function(o) {
  send_pending = 0;
  send_active = 0;
}

var props_send_callback =  
{
  success: props_send_success,
  failure: props_send_failure
};

function scale_percent(x,range) 
{
  return parseInt((x/range)*100);
}

function get_commandpath( id, callback )
{
  var send_callback = {
    success: callback,
    failure: console.log
  };
  var requestPath = "/cmd/getcontrolparams/";

  if ( typeof callback != "function" )
    return;

  if ( typeof id == "number" )
  {
    requestPath += id + "/";
  }

  YAHOO.util.Connect.asyncRequest('GET', host_override + requestPath, send_callback);
}
