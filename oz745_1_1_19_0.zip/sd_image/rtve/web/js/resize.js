
function ResizeableImgbox(id,img,parent,hx,hy,moveCallback,focusCallback, startMoveCB, endMoveCB )
{
  var MINSIZE = 38;
  var EDGE_THICKNESS = 7;
  var EDGEDIFFSIZE = 2*EDGE_THICKNESS + 3;
  var EDGEDIFFPOS = EDGE_THICKNESS + 1;
  var IMGDIFF = EDGE_THICKNESS + 2;
  
  var _x = 0;
  var _y = 0;
  
  var _width = hx;
  var _height = hy;
  
  var _maxWidth = 500;
  var _maxHeight = 500;
  
  var _minWidth = MINSIZE;
  var _minHeight = MINSIZE;

  var _container = document.createElement('DIV');
  _container.className = 'rtContainer';
  _container.style.position = "absolute";
  
  var _imgArea = document.createElement('IMG');
  _imgArea.className = 'rtImgArea';
  _imgArea.RTObject = this;
  _imgArea.src = img;
  if(id != null && id != "")
  {
    _imgArea.id = id;
    _imgArea.name = id;
  }
  
  var _rightEdge = document.createElement('DIV');
  _rightEdge.className = 'rtRightEdge';
  
  var _bottomEdge = document.createElement('DIV');
  _bottomEdge.className = 'rtBottomEdge';
 
  var _cornerHandle = document.createElement('DIV');
  _cornerHandle.className = 'rtCorner';
  
  var _leftCornerHandle = document.createElement('DIV');
  _leftCornerHandle.className = 'rtLeftCorner';
  
  var _topCornerHandle = document.createElement('DIV');
  _topCornerHandle.className = 'rtTopCorner';
  
  var _rightHandle = document.createElement('DIV');
  _rightHandle.className = 'rtRightHandle';

  var _bottomHandle = document.createElement('DIV');
  _bottomHandle.className = 'rtBottomHandle';
  
  var _topRightImageHandle = document.createElement('DIV');
  _topRightImageHandle.className = 'rtTopRightImage';
  
  var _bottomLeftImageHandle = document.createElement('DIV');
  _bottomLeftImageHandle.className = 'rtBottomLeftImage';
  
  var _leftEdge = document.createElement('DIV');
  _leftEdge.className = 'rtLeftEdge';
  
  var _topEdge = document.createElement('DIV');
  _topEdge.className = 'rtTopEdge';
  
  _cornerHandle.appendChild(_leftCornerHandle);
  _cornerHandle.appendChild(_topCornerHandle);
  
  _rightEdge.appendChild(_topRightImageHandle);
  _rightEdge.appendChild(_rightHandle);
  
  _bottomEdge.appendChild(_bottomHandle);
  _bottomEdge.appendChild(_bottomLeftImageHandle);

  _container.appendChild(_topEdge);
  _container.appendChild(_leftEdge);    
  _container.appendChild(_rightEdge);
  _container.appendChild(_bottomEdge);
  _container.appendChild(_cornerHandle);
  _container.appendChild(_imgArea);

  if(typeof(parent) == "string")
    p_element = document.getElementById(parent);
  if(p_element == null)
      return;
  
  var _parent = new dragObject(_container, null, new Position(0,0), new Position(600,300), centreStart, centreMove, null, true);   
  var _rightHandleDrag = new dragObject(_rightEdge, null, new Position(0, 3), new Position(0, 3), moveStart, rightHandleMove, moveEnd, true);
  var _bottomHandleDrag = new dragObject(_bottomEdge, null, new Position(3, 0), new Position(3, 0), moveStart, bottomHandleMove, moveEnd, true);
  var _cornerHandleDrag = new dragObject(_cornerHandle, null, new Position(0, 0), new Position(0, 0), moveStart, cornerHandleMove, moveEnd, true);
  
  _x = parseInt(p_element.style.left);
  _y = parseInt(p_element.style.top);
  
  UpdateBounds();
  UpdatePositions();
  AddToDocument();
  
  this.IsDragging = function()
  {
    return ( _parent.IsDragging() || _rightHandleDrag.IsDragging() || _bottomHandleDrag.IsDragging() || _cornerHandleDrag.IsDragging() );
  }

  function moveStart(eventObj, element)
  {
    if(element == _cornerHandle)
      document.body.style.cursor = 'se-resize';
    else if(element == _bottomEdge)
      document.body.style.cursor = 's-resize';
    else if(element == _rightEdge)
      document.body.style.cursor = 'e-resize';
    if (focusCallback != null)
      focusCallback();
    if ( startMoveCB != null )
      startMoveCB();
  }
  
  function moveEnd(element)
  {
    if ( endMoveCB != null )
      endMoveCB();
    UpdatePositions();
    document.body.style.cursor = 'auto'; 
  }

  function centreMove(newPos, element)
  {
	if ((newPos.X +_width) > _maxWidth) {
	  newPos.X = _maxWidth - _width;
      newPos.Apply(element);
	}
	if ((newPos.Y +_height) > _maxHeight) {
	  newPos.Y = _maxHeight - _height;
      newPos.Apply(element);
	}

    _x = newPos.X;
    _y = newPos.Y;
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }

  function centreStart(newPos, element)
  {
    if (focusCallback != null)
      focusCallback();
  }

  function rightHandleMove(newPos, element)
  {   
    _width = newPos.X + EDGE_THICKNESS;
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }
  
  function bottomHandleMove(newPos, element)
  {
    _height = newPos.Y + EDGE_THICKNESS;
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }

  function cornerHandleMove(newPos, element)
  {
    _width = newPos.X + EDGE_THICKNESS;
    _height = newPos.Y + EDGE_THICKNESS;
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }

  function UpdateBounds()
  {
    _rightHandleDrag.GetLowerBound().X = _minWidth - EDGE_THICKNESS;
    _rightHandleDrag.GetUpperBound().X = _maxWidth - EDGE_THICKNESS;
    _bottomHandleDrag.GetLowerBound().Y = _minHeight - EDGE_THICKNESS;
    _bottomHandleDrag.GetUpperBound().Y = _maxHeight - EDGE_THICKNESS;
    _cornerHandleDrag.GetLowerBound().X = _minWidth - EDGE_THICKNESS;
    _cornerHandleDrag.GetUpperBound().X = _maxWidth - EDGE_THICKNESS;
    _cornerHandleDrag.GetLowerBound().Y = _minHeight - EDGE_THICKNESS;
    _cornerHandleDrag.GetUpperBound().Y = _maxHeight - EDGE_THICKNESS;
  }
  
  function UpdatePositions()
  {
    if(_width < _minWidth)
      _width = _minWidth;
    if(_width > (_maxWidth - _x))
      _width = (_maxWidth - _x);
    
    if(_height < _minHeight)
      _height = _minHeight;
    if(_height > (_maxHeight - _y))
      _height = (_maxHeight - _y);
    
    _container.style.width = _width + 'px';  
    _container.style.height = _height + 'px';
    
    _imgArea.style.width = (_width - IMGDIFF) + 'px';
    _imgArea.style.height = (_height - IMGDIFF) + 'px';
    _rightEdge.style.left = (_width - EDGEDIFFPOS) + 'px';
    _rightEdge.style.height = (_height - EDGEDIFFSIZE) + 'px';
    _bottomEdge.style.top = (_height - EDGEDIFFPOS) + 'px';
    _bottomEdge.style.width = (_width - EDGEDIFFSIZE) + 'px';
    _cornerHandle.style.left = _rightEdge.style.left;
    _cornerHandle.style.top = _bottomEdge.style.top;
    _topEdge.style.width = (_width - EDGE_THICKNESS) + 'px';
    _leftEdge.style.height = (_height - EDGE_THICKNESS) + 'px';
    
    
    _rightHandle.style.top = ((_height - MINSIZE) / 2) + 'px';
    _bottomHandle.style.left = ((_width - MINSIZE) / 2) + 'px';
  }
  
  function Listen(yes)
  {
    if(yes)
    {
      _parent.StartListening();
      _rightHandleDrag.StartListening();
      _bottomHandleDrag.StartListening();
      _cornerHandleDrag.StartListening();
    }
    else
    {
      _parent.StopListening();
      _rightHandleDrag.StopListening();
      _bottomHandleDrag.StopListening();
      _cornerHandleDrag.StopListening();
    }
  }
  
  function AddToDocument()
  {
    if(typeof(parent) == "string")
      parent = document.getElementById(parent);
    
    if(parent == null || parent.appendChild == null)
    {
      var id = "sotc_rt_" + new Date().getTime() + Math.round(Math.random()*2147483647);
      while(document.getElementById(id) != null)
        id += Math.round(Math.random()*2147483647);
        
      document.write('<span id="'+ id + '"></span>');
      element = document.getElementById(id);
      element.parentNode.replaceChild(_container, element);
    }
    else
    {
      parent.appendChild(_container);
    }
    
    Listen(true); 
  }
    
  this.StartListening = function()
  { Listen(true); }
  
  this.StopListening = function()
  { Listen(false); }
  
  this.GetContainer = function()
  { return _container; }
    
  this.GetMinWidth = function()
  { return _minWidth; }
  
  this.GetMaxWidth = function()
  { return _maxWidth; }
  
  this.GetCurrentWidth = function()
  { return _width; }

  this.GetCurrentX = function()
  { return _x; }

  this.GetCurrentY = function()
  { return _x; }
  
  this.GetMinHeight = function()
  { return _minHeight; }
  
  this.GetMaxHeight = function()
  { return _maxHeight; }
  
  this.GetCurrentHeight = function()
  { return _height; }
  
  this.SetMinWidth = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < MINSIZE)
      value = MINSIZE;
    
    _minWidth = value;
    
    UpdatePositions();
    UpdateBounds();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);

    }
  
  this.SetMaxWidth = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < MINSIZE)
      value = MINSIZE;
    
    _maxWidth = value;
    
    UpdatePositions();
    UpdateBounds();
//    if (moveCallback != null)
      //moveCallback(_x,_y,_width,_height);
  }

  this.SetX = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < 0)
      value = 0;
    
    _x = value;
    _container.style.left = value + 'px';
    UpdatePositions();
    UpdateBounds();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }

    this.SetXQuiet = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < 0)
      value = 0;
    
    _x = value;
    _container.style.left = value + 'px';
    UpdatePositions();
    UpdateBounds();
  }

  this.SetY = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < 0)
      value = 0;
    
    _y = value;
    _container.style.top = value + 'px';
    
    UpdatePositions();
    UpdateBounds();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }
 
  this.SetYQuiet = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < 0)
      value = 0;
    
    _y = value;
    _container.style.top = value + 'px';
    
    UpdatePositions();
    UpdateBounds();
  }
  
  
  this.SetCurrentWidth = function(value)
  {
    value = parseInt(value);
    if(isNaN(value))
      value = 0;
    
    _width = value;
    
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }

 this.SetCurrentWidthQuiet = function(value)
  {
    value = parseInt(value);
    if(isNaN(value))
      value = 0;
    
    _width = value;
    
    UpdatePositions();
  }
  
  this.SetMinHeight = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < MINSIZE)
      value = MINSIZE;
    
    _minHeight = value;
    
    UpdatePositions();
    UpdateBounds();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }
  
  this.SetMaxHeight = function(value)
  {
    value = parseInt(value);
    if(isNaN(value) || value < MINSIZE)
      value = MINSIZE;
    
    _maxHeight = value;
    
    UpdatePositions();
    UpdateBounds();
    //if (moveCallback != null)
//      moveCallback(_x,_y,_width,_height);
  }
  
  this.SetCurrentHeight = function(value)
  {
    value = parseInt(value);
    if(isNaN(value))
      value = 0;
    
    _height = value;
    
    UpdatePositions();
    if (moveCallback != null)
      moveCallback(_x,_y,_width,_height);
  }
  this.SetCurrentHeightQuiet = function(value)
  {
    value = parseInt(value);
    if(isNaN(value))
      value = 0;
    
    _height = value;
    
    UpdatePositions();
  }

  this.SetImage = function(src)
  {
    _imgArea.src = src;
  }
  
  
}
