#! /bin/sh

RETVAL=0

RTVE_LOC=/mnt/rtve
#RTVE_LOC=/otb/rtve_2_1

SCRIPTS_LOC=${RTVE_LOC}/scripts
BIT_FILE=${RTVE_LOC}/bit/rtve.bit
MODULES_LOC=${RTVE_LOC}/drivers
UTILS=/mnt/utils

LIBS_LOC=${RTVE_LOC}/lib
IMG_LOC=${RTVE_LOC}/lib/rtve_libs.img
MNT_LOC=/media/rtve_libs
SYSLIBS_LOC=/usr/lib



make_liblinks() {
	CWD=`pwd -P`
	RETVAL=0

	if [ -z "$1" ]; then
		echo "No dir specified"
		return 4
	fi

	cd "$1"
	RETVAL=$?
	if [ $RETVAL -ne 0 ]; then
		echo "Failed to enter '$1'"
		return $RETVAL
	fi

	WD=`pwd -P`
	for F in `ls -1`; do
		ln -s ${WD}/${F} ${SYSLIBS_LOC}/${F}
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to symlink"
			cd "${CWD}"
			return $RETVAL
		fi
	done

	cd "${CWD}"
	return $RETVAL
}

unmake_liblinks() {
	CWD=`pwd -P`
	RETVAL=0

	if [ -z "$1" ]; then
		echo "No dir specified"
		return 4
	fi

	if [ ! -e "$1" ]; then
		return 0
	fi

	cd "$1"
	RETVAL=$?
	if [ $RETVAL -ne 0 ]; then
		echo "Failed to enter '$1'"
		return $RETVAL
	fi

	WD=`pwd -P`
	for F in `ls -1`; do
		rm -f ${SYSLIBS_LOC}/${F}
	done

	cd "${CWD}"
	return $RETVAL

}

mount_libimg() {
	if [ -d "${MNT_LOC}" ]; then
		mount | grep -q " ${MNT_LOC} "
		if [ $? -eq 0 ]; then
			return 0
		fi
	else
		mkdir -p "${MNT_LOC}"
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not make mount point"
			return $RETVAL
		fi
	fi

	mount ${IMG_LOC} ${MNT_LOC} -r -o loop
	RETVAL=$?
	if [ $RETVAL -ne 0 ]; then
		echo "Failed to mount"
		return $RETVAL
	fi

	return 0
}

unmount_libimg() {
	mount | grep -q " ${MNT_LOC} "
	if [ $? -eq 0 ]; then
		umount "${MNT_LOC}"
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not unmount"
			return $RETVAL
		fi
	fi
	rm -rf "${MNT_LOC}"
	RETVAL=$?
	return $RETVAL

}


unload_module_stub() {
	RETVAL=0
	MOD=`lsmod  | cut -d' ' -f1 | grep $1`
	if [ ! -z "${MOD}" ]; then
		unload_module "${MOD}"
		RETVAL=$?
	else
		echo "Module with stub '$1' not found?"
	fi
	return ${RETVAL}
}

unload_module() {
	RETVAL=0
	lsmod | grep -q "$1 "
	if [ $? -eq 0 ]; then
		rmmod $1
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to to unload module $1"
		else
			lsmod | grep -q "$1 "
			if [ $? -eq 0 ]; then
				RETVAL=1
				echo "Failed to to unload module $1"
			else
				echo "Module $1 unloaded"
			fi
		fi
	else
		echo "Module $1 already unloaded"
	fi

	return ${RETVAL}
}

load_module() {
	lsmod | grep -q "$1 "
	if [ $? -eq 0 ]; then
		echo "Module $1 already loaded"
		return 0;
	fi
	insmod $2
	RETVAL=$?
	if [ $RETVAL -ne 0 ]; then
		echo "Failed to to load module $1"
	else
		echo "Module $1 loaded"
	fi
	return ${RETVAL}
}

start() {
	if [ ! -e "${BIT_FILE}" ]; then
		RETVAL=1
		echo "Could not find bit file: ${BIT_FILE}"
		return ${RETVAL}
	fi

	DONE=`cat /sys/devices/amba.0/f8007000.devcfg/prog_done`
	if [ ${DONE} -eq 0 ]
	then
		${UTILS}/zynqProgramBitstream.elf ${BIT_FILE}
		echo "Letting the FPGA settle..."
		sleep 1
	fi

	if [ -f ${IMG_LOC} ]; then
		mount_libimg
		RETVAL=$?
		if [ ${RETVAL} -ne 0 ]; then
			echo "Failed to mount lib image"
			return ${RETVAL}
		fi
		make_liblinks ${MNT_LOC}/rtve_libs
	else
		make_liblinks ${LIBS_LOC}
	fi
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		echo "Failed to symlink libs"
		return ${RETVAL}
	fi

	load_module OmniTekFPGABus "${MODULES_LOC}/OmniTekFPGABus.ko"
	if [ $? -ne 0 ]; then
		return $RETVAL
	fi
	load_module OT_HC_LocalFPGA "${MODULES_LOC}/OT_HC_LocalFPGA.ko fpga_address=0x40000000 fpga_length=0x40000"
	if [ $? -ne 0 ]; then
		return $RETVAL
	fi

	load_module OT_Cap_RegisterAccess "${MODULES_LOC}/OT_Cap_RegisterAccess.ko"
	if [ $? -ne 0 ]; then
		return $RETVAL
	fi

	FB=`${SCRIPTS_LOC}/which_fb . ${SCRIPTS_LOC}/list_caps`
	if [ -z "${FB}" ]; then
		echo "Could not detimine framebuffer to load"
	else
		load_module ${FB} "${MODULES_LOC}/${FB}.ko"
		if [ $? -ne 0 ]; then
			return $RETVAL
		fi
	fi

	killall -0 RTVE &> /dev/null
	RETVAL=$?
	if [ ${RETVAL} -eq 0 ]; then
		echo "RTVE already running"
		RETVAL=1
		return ${RETVAL}
	fi

	cd ${RTVE_LOC}/web
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		echo "Couldnt change to web directory"
		return ${RETVAL}
	fi

	${SCRIPTS_LOC}/hdmi_in.sh
	killall -0 adv7511
	if [ $? -ne 0 ]; then
		nohup ${UTILS}/adv7511 &> /var/log/adv7511 &
	fi
	${SCRIPTS_LOC}/sdi_setup.sh

	nohup ../RTVE -w -t 1985 &> /dev/null &

	RETVAL=$?
	return ${RETVAL}
}

stop() {
	killall -0 RTVE &> /dev/null
	RETVAL=$?
	if [ $RETVAL -eq 0 ]; then
		killall RTVE &> /dev/null
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to kill RTVE"
			return 1
		fi
	fi
	RETVAL=0

	unload_module OT_Cap_RegisterAccess
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		return $RETVAL
	fi

	unload_module OT_HC_LocalFPGA
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		return $RETVAL
	fi

	unload_module OmniTekFPGABus
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		return $RETVAL
	fi

        if [ -e /sys/class/vtconsole/vtcon1/bind ]; then
                echo 0 > /sys/class/vtconsole/vtcon1/bind
        fi

	unload_module_stub omnitekfb
	RETVAL=$?
	if [ ${RETVAL} -ne 0 ]; then
		return $RETVAL
	fi

	if [ -e /dev/xdevcfg ]; then
		echo -n > /dev/xdevcfg
	fi

	unmake_liblinks ${LIBS_LOC}
	unmake_liblinks ${MNT_LOC}/rtve_libs
	unmount_libimg

	return $RETVAL
}

case "$1" in
	start)
		start
	;;
	stop)
		stop
	;;
	*)
		echo "Usage: $0 {start|stop}"
		exit 2
esac

exit $RETVAL
