#! /bin/ash

/mnt/gpio/sdi_tx_enable.sh  1 1
/mnt/gpio/sdi_tx_enable.sh  2 0
/mnt/gpio/sdi_tx_enable.sh  3 0
/mnt/gpio/sdi_tx_enable.sh  4 0
