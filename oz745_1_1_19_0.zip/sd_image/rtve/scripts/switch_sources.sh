#! /bin/sh

sdi="0x74f00000"
hdmi="0x74f00004"
fb=1
rtve=2

usage ()
{
  echo  "Usage: `basename $0` <hdmi,sdi> <rtve,fb>"
  exit 1
}

if [ $# -ne 2 ]
then
  usage
fi

if [ "$1" != "hdmi" ] && [ "$1" != "sdi" ]
then
  usage
fi

if [ "$2" != "fb" ] && [ "$2" != "rtve" ]
then
  usage
fi

eval "devmem \$$1 32 \$$2"