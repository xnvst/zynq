#!/bin/sh

if [ $# == 2 ] &&  [ $1 -gt -1 ] && [ $1 -lt 3 ]
then
sdiChan=$1
echo $2 > /dev/oz745/gpio/spi_ad$sdiChan/value
else
echo "Usage : sdi_channel chan value"
echo "      chan = 0..2"
echo "      value = 0 or 1"
fi


