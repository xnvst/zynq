#!/bin/sh

if [ $# == 1 ] &&  [ $1 -gt -1 ] && [ $1 -lt 2 ]
then
echo $1 > /dev/oz745/gpio/subfilt/value
else
echo "Usage : sub_filter value"
echo "      value = 0 or 1"
fi


