#!/bin/sh

if [ $# == 1 ] &&  [ $1 -gt -1 ] && [ $1 -lt 4 ]
then
dipSw=$1
cat /dev/o745/gpio/dip_sw$dipSw/value
else
echo "Usage: read_sw chan"
echo "       chan 0..3"
fi


