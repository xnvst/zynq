#!/bin/sh

if [ $# == 2 ] &&  [ $1 -gt 0 ] && [ $1 -lt 5 ]
then
sdiChan=`expr $1`
echo $2 > /dev/oz745/gpio/sdhd$sdiChan/value
else
echo "Usage : sdi_sd_hd chan value"
echo "      chan = 1..4"
echo "      value = 0 or 1"
fi


