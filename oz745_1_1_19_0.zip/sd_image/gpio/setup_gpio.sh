#!/bin/sh

echo "Setting up GPIOs..."

# Set the base address of the GPIO switch
baseGpio=240

if [ -d /sys/class/gpio/gpiochip${baseGpio} ]
then
# We are going to symlink each device into /dev/oz745/gpio
# so we need to setup the destination directory

# Set the destination directory for the symlinks
gpio_dir=/dev/oz745/gpio

mkdir -p /dev/oz745
mkdir -p ${gpio_dir}

# Setup each of the DIP Switches
gpio=`expr $baseGpio + 0`
name=dip_sw0
direction="in"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 1`
name=dip_sw1
direction="in"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 2`
name=dip_sw2
direction="in"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 3`
name=dip_sw3
direction="in"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

# Setup the gpio outputs
gpio=`expr $baseGpio + 4`
name=spi_ad0
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 5`
name=spi_ad1
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 6`
name=spi_ad2
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 7`
name=subfilt
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 8`
name=tx_en1
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 9`
name=sdhd1
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 10`
name=tx_en2
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 11`
name=sdhd2
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 12`
name=tx_en3
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 13`
name=sdhd3
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 14`
name=tx_en4
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

gpio=`expr $baseGpio + 15`
name=sdhd4
direction="out"
echo ${gpio} > /sys/class/gpio/export
ln -s /sys/class/gpio/gpio${gpio} ${gpio_dir}/${name}
echo ${direction} > ${gpio_dir}/${name}/direction

fi

for i in $(seq 1 4)
do
echo "Setting sdi tx enable chan $1 to 1"
./sdi_tx_enable.sh $i 1
echo "Setting sdi sd hd $1 to 0"
./sdi_sd_hd.sh $i 0
done

echo "GPIO setup complete."
