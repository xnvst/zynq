#!/bin/sh
#First SDI Channel at gpio260

if [ $# == 1 ] &&  [ $1 -gt -1 ] && [ $1 -lt 8 ]
then
	let "res=$1&1"
	echo $res
	echo $res >> /dev/oz745/gpio/spi_ad0/value
	let "res=($1>>1)&1"
	echo $res
	echo $res >> /dev/oz745/gpio/spi_ad1/value
	let "res=($1>>2)&1"
	echo $res
	echo $res >> /dev/oz745/gpio/spi_ad2/value
else
	echo "Usage : sdi_spi_sel chan"
	echo "      chan = 0..7"
fi

