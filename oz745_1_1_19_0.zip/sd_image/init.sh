#!/bin/sh +x
############################################################
#
# Startup script for the OmniTek oz745 Development Platform
#
############################################################

echo "Running Init Script 1.0.2.0"

if [ -d /mnt/scripts ]; then
  cd /mnt/scripts

  ./setup_i2c_gpio.sh

  ./start_network.sh
	
  ./setup_rtc.sh
	
  ./misc.sh

  ./configure_time.sh

  cd

if [ ! -e /dev/xdevcfg ]; then
  echo "Enabling FPGA Programming Interface"
  mknod /dev/xdevcfg c 259 0
fi

fi

if [ -f /mnt/utils/oz745_id.elf ]; then
  /mnt/utils/oz745_id.elf
fi

if [ -f /mnt/autorun.sh ]; then
  echo source /mnt/autorun.sh >> /etc/profile
fi
