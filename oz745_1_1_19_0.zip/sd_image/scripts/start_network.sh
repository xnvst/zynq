#!/bin/sh
############################################################
#
# Script to start-up the network interface on the
# OmniTek oz745 Development Platform
#
############################################################
echo "Starting Networking"

ifconfig lo up
echo "127.0.0.1   localhost" >> /etc/hosts

ifconfig eth0 up
ifplugd -r /mnt/scripts/network.sh -a -I -f

