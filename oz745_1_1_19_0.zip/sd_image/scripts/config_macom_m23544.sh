#!/bin/sh
############################################################
#
# Script to setup the Macom M23544 Eq on the
# OmniTek oz745 Development Platform
#
############################################################
# Registers required to get the EYE input equalizer (see Macom M23544 errata)
 
# First read the Macom part die revision:
MACOM_SPI_READ="/mnt/utils/spi/macom_read -s 12" 
MACOM_SPI_WRITE="/mnt/utils/spi/macom_write -s 12" 
version=`${MACOM_SPI_READ} /dev/spidev0.2 0x01`

# Check to see whether the device is present - assume if we get a fail that all bets are off
devicePresent=`echo ${version}|awk '{print match($0,"Failed")}'`;
if [ "${devicePresent}" == "0" ]; then
  echo "Configuring Macom 12G Eq - V1.0"
  echo "Macom Device - M23544 Rev" ${version}
  # If the result is “0x01”, then perform the following writes (with other die revisions, this may not be necessary):
  if [ "${version}" == "0x01" ]; then
	${MACOM_SPI_WRITE} /dev/spidev0.2 0x22 0x09
	${MACOM_SPI_WRITE} /dev/spidev0.2 0x32 0x3F
    ${MACOM_SPI_WRITE} /dev/spidev0.2 0x3F 0x03
    ${MACOM_SPI_WRITE} /dev/spidev0.2 0x42 0x2C
    ${MACOM_SPI_WRITE} /dev/spidev0.2 0x11 0x02
  fi

  # These non-default register values are required to set up the M23544 for the Ultra application:
 
  ${MACOM_SPI_WRITE} /dev/spidev0.2 0x02 0x16
  ${MACOM_SPI_WRITE} /dev/spidev0.2 0x03 0x07
  ${MACOM_SPI_WRITE} /dev/spidev0.2 0x04 0x02
  ${MACOM_SPI_WRITE} /dev/spidev0.2 0x05 0x07
fi
