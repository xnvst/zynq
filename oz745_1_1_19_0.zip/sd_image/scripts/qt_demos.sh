#! /bin/sh

RETVAL=0

SCRIPTS_LOC=/mnt/scripts
UTILS=/mnt/utils
FB=/dev/fb0

QTAPPS=/mnt/qt_apps


kill_program() {
	killall -0 "$1" &> /dev/null
	RETVAL=$?
	if [ $RETVAL -eq 0 ]; then
		killall "$1" &> /dev/null
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to kill $1"
			return 1
		fi
	fi
	RETVAL=0
	return 0
}

stop() {
	kill_program helloqt
	RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi

	kill_program basicweb
	RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi

	if [ "$1" == "full" ]; then
		${SCRIPTS_LOC}/qt_lib.sh stop
		RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi
	fi

	return $RETVAL
}

start() {
	${SCRIPTS_LOC}/qt_lib.sh start
	RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi

	if [ ! -e ${FB} ]; then
		echo "No framebuffer detected..."
		return 3
	fi

	stop apps
	RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi

	case "$1" in
		sidebyside)
			cd ${QTAPPS}/web_client
			nohup ./basicweb -qws -geometry 960x1080+0+0 &> /dev/null &
			RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi

			cd ${QTAPPS}/helloqt
			nohup ./helloqt -geometry +970+00  &> /dev/null &
			RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi
		;;
		web)
			cd ${QTAPPS}/web_client
			nohup ./basicweb -qws &> /dev/null &
			RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi
		;;
		example)
			cd ${QTAPPS}/helloqt
			nohup ./helloqt -qws &> /dev/null &
			RETVAL=$?; if [ $RETVAL -ne 0 ]; then return $RETVAL; fi
		;;
	esac

	return $RETVAL
}

case "$1" in
	web)
		start web
	;;
	example)
		start example
	;;
	sidebyside)
		start sidebyside
	;;
	fullstop)
		stop full
	;;
	stop)
		stop apps
	;;
	*)
		echo "Usage: $0 {fullstop|stop|sidebyside|web|example}"
		exit 2
esac

exit $RETVAL
