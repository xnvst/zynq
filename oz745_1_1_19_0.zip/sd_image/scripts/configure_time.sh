#!/bin/sh
############################################################
#
# Script to setup the time on the
# OmniTek oz745 Development Platform
#
############################################################
# Setup the timezone information
if [ -d /mnt/etc/zoneinfo ]; then
	ln -s /mnt/etc/zoneinfo /etc/zoneinfo
	ln -s /mnt/etc/zoneinfo-leaps /etc/zoneinfo-leaps
	ln -s /etc/zoneinfo /etc/zoneinfo-posix

	# Set the timezone to London
	ln -s /etc/zoneinfo/Europe/London /etc/localtime
fi

# Start the ntpd client to update the time if connected to the internet
./start_ntp.sh
