#!/bin/sh

INTERFACE="eth0"
ACTION="up"
if [ $# -eq 2 ]
then
  INTERFACE=$1
  ACTION=$2
fi

DS=`cat /dev/oz745/gpio/dip_sw0/value`
if [ "${ACTION}" == "down" ]
then
  killall udhcpc
fi

if [ "${ACTION}" == "up" ]
then
  if [ $DS -eq 1 ]
  then
    echo "use dhcp..."

    HOSTNAME="OZ745-`/mnt/utils/oz745_id.elf -m -r`"
    if [ -f /mnt/hostname ]
    then
      HOSTNAME="`cat /mnt/hostname`"
    fi
    hostname ${HOSTNAME}

    udhcpc -R -i ${INTERFACE} -x hostname:${HOSTNAME} -S -b -s /mnt/scripts/udhcpc.handler.sh
  else
    ifconfig ${INTERFACE} 169.254.45.55
    echo "Manually set to 169.254.45.55"
    echo > /etc/resolv.conf
  fi
fi
