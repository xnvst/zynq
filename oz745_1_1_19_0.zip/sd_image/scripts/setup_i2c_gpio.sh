#!/bin/sh
############################################################
#
# Script to setup the ic2 and gpio devices on the
# OmniTek oz745 Development Platform
#
############################################################
echo "Setup i2c Utils"
ln -s /mnt/i2c /i2c

echo "Enable i2c GPIOs"
if [ -d /mnt/gpio ]
then
  ln -s /mnt/gpio /gpio
  cd /mnt/gpio
  ./setup_gpio.sh
fi
