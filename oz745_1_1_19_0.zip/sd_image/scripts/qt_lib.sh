#! /bin/sh

RETVAL=0

QT_LIB=/usr/local/Trolltech
QT_SETTINGS=/Settings
IMG_LOC=/mnt/lib/qt_lib.img

start() {
	if [ ! -e "${IMG_LOC}" ]; then
		RETVAL=1
		echo "Cannot find library image"
		return $RETVAL
	fi

	if [ ! -d "${QT_SETTINGS}" ]; then
		mkdir -p "${QT_SETTINGS}"
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not make mount point ${QT_SETTINGS}"
			return $RETVAL
		fi
		mount none -t tmpfs ${QT_SETTINGS}
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to mount ${QT_SETTINGS}"
			return $RETVAL
		fi
	fi

	if [ ! -d "${QT_LIB}" ]; then
		mkdir -p "${QT_LIB}"
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not make mount point ${QT_LIB}"
			return $RETVAL
		fi
		mount ${IMG_LOC} ${QT_LIB} -r -o loop
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Failed to mount ${QT_LIB}"
			return $RETVAL
		fi
	fi

	return $RETVAL
}

stop() {
	if [ -e ${QT_LIB} ]; then
		mount | grep -q " ${QT_LIB} "
		if [ $? -eq 0 ]; then
			umount ${QT_LIB}
			RETVAL=$?
			if [ $RETVAL -ne 0 ]; then
				echo "Could not unmount ${QT_LIB}"
				return $RETVAL
			fi
		fi
		rm -rf ${QT_LIB}
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not cleanup ${QT_LIB}"
			return $RETVAL
		fi
	fi

	if [ -e ${QT_SETTINGS} ]; then
		mount | grep -q " ${QT_SETTINGS} "
		if [ $? -eq 0 ]; then
			umount ${QT_SETTINGS}
			RETVAL=$?
			if [ $RETVAL -ne 0 ]; then
				echo "Could not unmount ${QT_SETTINGS}"
				return $RETVAL
			fi
		fi
		rm -rf ${QT_SETTINGS}
		RETVAL=$?
		if [ $RETVAL -ne 0 ]; then
			echo "Could not cleanup ${QT_SETTINGS}"
			return $RETVAL
		fi
	fi

	return $RETVAL
}

case "$1" in
	start)
		start
		
	;;
	stop)
		stop
	;;
	*)
		echo "Usage: $0 {start|stop}"
		exit 2
esac

exit $RETVAL
