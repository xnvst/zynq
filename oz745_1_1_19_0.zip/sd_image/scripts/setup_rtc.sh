#!/bin/sh
############################################################
#
# Script to setup the RTC on the
# OmniTek oz745 Development Platform
#
############################################################
echo "Enable RTC Charging"
# Set the MUX to Bus 1
/mnt/i2c/i2cset -f -y 1 0x77 0x01
/mnt/i2c/i2cset -f -y 1 0x68 0x08 0x20
/mnt/i2c/i2cset -f -y 1 0x68 0x09 0x45

