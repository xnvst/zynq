#! /bin/sh

/mnt/rtve/scripts/rtve.sh $@

exit $?
