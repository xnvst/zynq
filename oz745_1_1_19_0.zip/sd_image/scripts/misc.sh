#!/bin/sh
############################################################
#
# Script to setup miscellaneous items on the
# OmniTek oz745 Development Platform
#
############################################################
echo "Turn on Divide by 0.0001 clock"
# Set the MUX to Bus 1
/mnt/i2c/i2cset -f -y 1 0x77 0x01
/mnt/i2c/i2cset -y 1 0x59 0 0x04


echo "Reset the lmh1983"
# set the MUX to bus 1
/mnt/i2c/i2cset -f -y 1 0x77 0x01
# switch clocks
/mnt/i2c/i2cset -f -y 0 0x66 0x09 0x12
/mnt/i2c/i2cset -f -y 0 0x66 0x09 0x10

echo "Suppress DMESG output on console" 
echo "4 4 1 4" > /proc/sys/kernel/printk

mainEyeEq=`/mnt/utils/oz745_id.elf -e`
if [ "${mainEyeEq}" == "Macom 12G" ]; then
	./config_macom_m23544.sh
fi
