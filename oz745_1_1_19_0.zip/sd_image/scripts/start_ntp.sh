#!/bin/sh
############################################################
#
# Script to start the ntp client on the
# OmniTek oz745 Development Platform
#
############################################################
mkdir -p /var/services
ln -s /var/service/ntpd /var/services/ntpd
nohup runsvdir /var/services &> /dev/null &
